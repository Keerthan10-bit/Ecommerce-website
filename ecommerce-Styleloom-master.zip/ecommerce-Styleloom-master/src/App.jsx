// src/App.jsx
import React, { useState, useEffect } from 'react';
import Nav from './Pages/Nav';
import { Routes, Route } from 'react-router-dom';
import Home from './Pages/Home';
import Products from './Pages/Products/Products';
import Cart from './Pages/products/Cart';

import Checkout from './Pages/Checkout';
import Help from './Pages/Help';

const App = () => {
  // Global cart state with sessionStorage persistence
  const [cartItems, setCartItems] = useState(() => {
    const saved = sessionStorage.getItem('cartItems');
    return saved ? JSON.parse(saved) : [];
  });


  // Product page navigation state lifted to parent
  const [productState, setProductState] = useState(() => {
    const saved = sessionStorage.getItem('productState');
    return saved ? JSON.parse(saved) : {
      currentPage: 'home',
      selectedCategory: null,
      selectedProduct: null,
      sortBy: 'popularity',
      priceRange: 'all',
    };
  });

  // Persist states to sessionStorage
  useEffect(() => {
    sessionStorage.setItem('cartItems', JSON.stringify(cartItems));
  }, [cartItems]);



  useEffect(() => {
    sessionStorage.setItem('productState', JSON.stringify(productState));
  }, [productState]);

  // Cart functions
  const addToCart = (product) => {
    setCartItems(prev => {
      const found = prev.find(item => item.id === product.id);
      if (found) {
        return prev.map(item =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { ...product, quantity: 1 }];
    });
  };

  const updateQuantity = (productId, newQty) => {
    if (newQty <= 0) {
      removeFromCart(productId);
      return;
    }
    setCartItems(prev =>
      prev.map(item =>
        item.id === productId ? { ...item, quantity: newQty } : item
      )
    );
  };

  const removeFromCart = (productId) => {
    setCartItems(prev =>
      prev.filter(item => item.id !== productId)
    );
  };

 
  return (
    <>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route
          path="/products"
          element={
            <Products
              cartItems={cartItems}
              addToCart={addToCart}
              productState={productState}
              setProductState={setProductState}
            
            />
          }
        />
       
        <Route
          path="/checkout"
          element={
            <Checkout
              cartItems={cartItems}
            />
          }
        />
        <Route
          path="/cart"
          element={
            <Cart
              cartItems={cartItems}
              updateQuantity={updateQuantity}
              removeFromCart={removeFromCart}
            />
          }
        />
        <Route
          path="/help"
          element={
           <Help/>
            
          }
        />
        
      </Routes>
    </>
  );
};

export default App;
