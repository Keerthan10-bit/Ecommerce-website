import React, { useState } from 'react';

const StyleLoomFooter = () => {
  const [email, setEmail] = useState('');

  const handleSubmit = () => {
    // Handle newsletter subscription
    console.log('Newsletter subscription:', email);
    setEmail('');
  };

  return (
    <footer className="w-full bg-gradient-to-r from-slate-600 via-slate-700 to-slate-800 relative">
      {/* Dashed border top */}
      <div className="w-full border-t-2 border-dashed border-slate-400"></div>
      
      {/* Main Footer Content */}
      <div className="max-w-7xl mx-auto">
        <div className="px-4 sm:px-6 md:px-8 lg:px-12 xl:px-16 py-8 sm:py-10 md:py-12">
          {/* Top Section - Navigation and Newsletter */}
          <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-8 lg:gap-12 mb-12 lg:mb-16">
            
            {/* Left - Navigation Links */}
            <div className="flex flex-col sm:flex-row gap-6 sm:gap-8 md:gap-12 lg:gap-16">
              <a 
                href="#" 
                className="text-white/80 hover:text-white transition-colors duration-200 text-base sm:text-lg font-medium"
              >
                Home
              </a>
              <a 
                href="#" 
                className="text-white/80 hover:text-white transition-colors duration-200 text-base sm:text-lg font-medium"
              >
                Products
              </a>
            </div>

            {/* Right - Newsletter Subscription */}
            <div className="w-full lg:w-auto">
              <div className="text-center lg:text-right mb-4">
                <h3 className="text-white/90 text-base sm:text-lg font-medium">
                  Subscribe to Newsletter
                </h3>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-3 lg:gap-4">
                <div className="relative flex-1 lg:min-w-[280px]">
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Your Email"
                    className="w-full px-4 py-3 bg-slate-800/80 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-slate-500 focus:border-transparent transition-all duration-200"
                  />
                </div>
                <button
                  onClick={handleSubmit}
                  className="flex items-center justify-center px-6 py-3 bg-slate-700 hover:bg-slate-600 text-white rounded-lg transition-all duration-200 hover:shadow-lg group min-w-[120px] sm:min-w-auto"
                >
                  <span className="mr-2">Subscribe</span>
                  <svg 
                    className="w-4 h-4 group-hover:translate-x-1 transition-transform duration-200" 
                    fill="none" 
                    stroke="currentColor" 
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                  </svg>
                </button>
              </div>
            </div>
          </div>

          {/* Dashed Divider */}
          <div className="w-full border-t-2 border-dashed border-slate-400 mb-8"></div>

          {/* Bottom Section - Copyright and Legal Links */}
          <div className="flex flex-col sm:flex-row justify-between items-center gap-4 sm:gap-6">
            
            {/* Left - Copyright */}
            <div className="text-white/70 text-sm sm:text-base order-2 sm:order-1">
              © 2025 StyleLoom. All rights reserved.
            </div>

            {/* Right - Legal Links */}
            <div className="flex flex-col sm:flex-row gap-3 sm:gap-6 lg:gap-8 order-1 sm:order-2">
              <a 
                href="#" 
                className="text-white/70 hover:text-white/90 transition-colors duration-200 text-sm sm:text-base text-center"
              >
                Terms & Conditions
              </a>
              <a 
                href="#" 
                className="text-white/70 hover:text-white/90 transition-colors duration-200 text-sm sm:text-base text-center"
              >
                Privacy Policy
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default StyleLoomFooter;