import React from 'react';

const ProductGrind = () => {
  const products = [
    {
      title: "Floral Bloom Maxi Dress",
      detail: "Slim Fit",
      price: "$84.99",
      image: "https://images.unsplash.com/photo-1539109136881-3be0616acf4b?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80",
      category: "Womenswear",
      buttonText: "Shop Now"
    },
    {
      title: "Timeless A-line Evening Dress",
      detail: "Ankle-length",
      price: "$109.99",
      image: "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80",
      category: "Womenswear",
      buttonText: "Shop Now"
    },
    {
      title: "Elegant Evening Gown",
      detail: "Flowing Skirt",
      price: "$89.99",
      image: "https://images.unsplash.com/photo-1551232864-3f0890e580d9?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80",
      category: "Womenswear",
      buttonText: "Shop Now"
    },
    {
      title: "Sophisticate Sun Hat",
      detail: "One size fits all",
      price: "$24.99",
      image: "https://images.unsplash.com/photo-1533055640609-24b498dfd74c?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80",
      category: "Accessories",
      buttonText: "Shop Now"
    },
    {
      title: "Urban Chic Handbag",
      detail: "Premium leather",
      price: "$89.99",
      image: "https://images.unsplash.com/photo-1584917865442-de89df76afd3?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80",
      category: "Accessories",
      buttonText: "Shop Now"
    },
    {
      title: "Boho Chic Printed Scarf",
      detail: "Lightweight",
      price: "$19.99",
      image: "https://images.unsplash.com/photo-1441986300917-64674bd600d8?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80",
      category: "Womenswear",
      buttonText: "Shop Now"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-800 via-slate-700 to-slate-900 p-4 sm:p-6 lg:p-8">
      <div className="max-w-7xl mx-auto">
        {/* Products Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
          {products.map((product, index) => (
            <div 
              key={index} 
              className="group relative bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl overflow-hidden hover:bg-white/15 hover:border-white/30 transition-all duration-300 hover:shadow-2xl hover:shadow-black/20"
            >
              {/* Product Image */}
              <div className="relative h-48 sm:h-56 lg:h-64 overflow-hidden bg-gradient-to-br from-gray-100 to-gray-200">
                <img 
                  src={product.image} 
                  alt={product.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                
                {/* Category Badge */}
                <div className="absolute top-3 left-3 bg-black/70 backdrop-blur-sm text-white text-xs px-3 py-1 rounded-full font-medium">
                  {product.category}
                </div>
                
                {/* Shop Now Button Overlay */}
                <div className="absolute bottom-3 right-3">
                  <button className="bg-black/80 hover:bg-black text-white text-xs px-3 py-2 rounded-full font-medium backdrop-blur-sm transition-all duration-200 hover:scale-105 flex items-center gap-1">
                    {product.buttonText}
                    <svg 
                      className="w-3 h-3" 
                      fill="none" 
                      stroke="currentColor" 
                      viewBox="0 0 24 24"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                    </svg>
                  </button>
                </div>
              </div>
              
              {/* Product Details */}
              <div className="p-4 sm:p-5">
                <h3 className="text-white font-bold text-sm sm:text-base mb-2 leading-tight group-hover:text-blue-200 transition-colors">
                  {product.title}
                </h3>
                
                <div className="flex items-center justify-between text-xs sm:text-sm">
                  <span className="text-gray-300 font-medium">
                    {product.detail}
                  </span>
                  <span className="text-white font-bold">
                    {product.price}
                  </span>
                </div>
              </div>
              
              {/* Subtle glow effect on hover */}
              <div className="absolute inset-0 bg-gradient-to-r from-blue-500/0 via-purple-500/0 to-pink-500/0 group-hover:from-blue-500/5 group-hover:via-purple-500/5 group-hover:to-pink-500/5 transition-all duration-500 pointer-events-none rounded-xl"></div>
            </div>
          ))}
        </div>
        
        {/* Bottom spacing for mobile */}
        <div className="h-8"></div>
      </div>
    </div>
  );
};

export default ProductGrind;