// src/Pages/CheckoutForm.jsx
import React, { useState } from 'react';
import { 
  ChevronDownIcon, 
  ShieldCheckIcon, 
  CreditCardIcon, 
  LockClosedIcon, 
  TruckIcon, 

  CubeIcon, 
  MapPinIcon, 
  PhoneIcon, 
  EnvelopeIcon, 
  UserIcon, 
  StarIcon 
} from '@heroicons/react/24/outline';
import { 
  Facebook, 
  Twitter, 
  Instagram, 
  Youtube 
} from 'lucide-react';

const CheckoutForm = () => {
  const [deliveryType, setDeliveryType] = useState('delivery');
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phoneNumber: '',
    country: '',
    city: '',
    state: '',
    zipCode: '',
    discountCode: ''
  });
  const [agreedToTerms, setAgreedToTerms] = useState(false);

  const cartItems = [
    {
      name: 'HIGHLANDER Men Printed Regular Fit Cotton Shirt',
      quantity: 1,
      price: 599,
      image: 'https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=500&h=500&fit=crop&crop=center'
    },
    {
      name: 'Campus Sutra Men Solid Casual T-Shirt',
      quantity: 1,
      price: 329,
      image: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=500&h=500&fit=crop&crop=center'
    }
  ];

  const subtotal = 928;
  const shipping = 0;
  const discount = -93;
  const total = 835;

  const handleInputChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!agreedToTerms) {
      alert('Please agree to the Terms and Conditions');
      return;
    }
    // Handle checkout logic here
    console.log('Checkout data:', formData);
    alert('Order placed successfully!');
  };

  return (
    <>
      <style>
        {`
          .glass-effect {
            backdrop-filter: blur(10px);
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
          }
          .form-input {
            transition: all 0.3s ease;
          }
          .form-input:focus {
            transform: translateY(-1px);
            box-shadow: 0 8px 25px rgba(59, 130, 246, 0.3);
          }
          .checkout-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 30px rgba(59, 130, 246, 0.4);
          }
          .social-icon {
            transition: all 0.3s ease;
          }
          .social-icon:hover {
            transform: scale(1.2) rotate(5deg);
          }
          .footer-link {
            transition: all 0.3s ease;
          }
          .footer-link:hover {
            transform: translateY(-2px);
          }
        `}
      </style>
      
      <div className="min-h-screen bg-gradient-to-br from-[#1e293b] via-[#334155] to-[#475569] text-white font-['Inter']">
        {/* Enhanced Header */}
        <header className="relative border-b border-slate-600/30 py-8 bg-gradient-to-r from-[#0f172a] via-[#1e293b] to-[#334155] shadow-2xl">
          <div className="max-w-7xl mx-auto px-4">
            {/* Brand */}
            <div className="flex items-center justify-between mb-8">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center shadow-xl">
                  <CubeIcon className="w-6 h-6 text-white" />
                </div>
                <h1 className="text-3xl font-bold text-white">StyleLoom</h1>
              </div>
              <div className="text-right">
                <div className="text-sm text-slate-300">Secure Checkout</div>
                <div className="flex items-center space-x-2 text-green-400">
                  <LockClosedIcon className="w-4 h-4" />
                  <span className="text-sm font-medium">SSL Protected</span>
                </div>
              </div>
            </div>
            
            {/* Progress Steps */}
            <div className="flex items-center justify-center space-x-8">
              <div className="flex items-center">
                <div className="w-10 h-10 bg-gradient-to-r from-green-500 to-emerald-600 rounded-full flex items-center justify-center shadow-xl">
                 
                </div>
                <span className="ml-3 text-slate-300 font-medium">Cart</span>
              </div>
              
              <div className="w-16 h-0.5 bg-gradient-to-r from-green-500 to-blue-500"></div>
              
              <div className="flex items-center">
                <div className="w-10 h-10 bg-gradient-to-r from-green-500 to-emerald-600 rounded-full flex items-center justify-center shadow-xl">
                
                </div>
                <span className="ml-3 text-slate-300 font-medium">Review</span>
              </div>
              
              <div className="w-16 h-0.5 bg-gradient-to-r from-blue-500 to-purple-500"></div>
              
              <div className="flex items-center">
                <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-bold shadow-xl">
                  3
                </div>
                <span className="ml-3 text-white font-bold">Checkout</span>
              </div>
            </div>
          </div>
        </header>

        <div className="max-w-7xl mx-auto px-4 py-12">
          <form onSubmit={handleSubmit}>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              {/* Left Column - Form */}
              <div className="bg-gradient-to-br from-[#0f172a] to-[#1e293b] rounded-3xl p-8 shadow-2xl border border-slate-600/30">
                <h2 className="text-3xl font-bold mb-8 flex items-center">
                  <UserIcon className="w-8 h-8 mr-3 text-blue-400" />
                  Checkout Details
                </h2>
                
                {/* Shipping Information */}
                <div className="mb-8">
                  <h3 className="text-xl font-bold mb-6 text-slate-200">Shipping Information</h3>
                  
                  {/* Delivery Options */}
                  <div className="grid grid-cols-2 gap-4 mb-8">
                    <button
                      type="button"
                      onClick={() => setDeliveryType('delivery')}
                      className={`p-4 rounded-2xl flex items-center justify-center space-x-3 transition-all duration-300 transform hover:scale-105 ${
                        deliveryType === 'delivery' 
                          ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white shadow-xl' 
                          : 'bg-[#1e293b] border border-slate-600 text-slate-300 hover:border-slate-500'
                      }`}
                    >
                      <TruckIcon className="w-6 h-6" />
                      <span className="font-medium">Delivery</span>
                    </button>
                    
                    <button
                      type="button"
                      onClick={() => setDeliveryType('pickup')}
                      className={`p-4 rounded-2xl flex items-center justify-center space-x-3 transition-all duration-300 transform hover:scale-105 ${
                        deliveryType === 'pickup' 
                          ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white shadow-xl' 
                          : 'bg-[#1e293b] border border-slate-600 text-slate-300 hover:border-slate-500'
                      }`}
                    >
                      <CubeIcon className="w-6 h-6" />
                      <span className="font-medium">Pick up</span>
                    </button>
                  </div>

                  {/* Form Fields */}
                  <div className="space-y-6">
                    <div>
                      <label className="block text-base font-bold text-slate-200 mb-3">
                        Full name <span className="text-red-400">*</span>
                      </label>
                      <div className="relative">
                        <UserIcon className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-slate-400" />
                        <input
                          type="text"
                          name="fullName"
                          value={formData.fullName}
                          onChange={handleInputChange}
                          placeholder="Enter your full name"
                          required
                          className="form-input w-full pl-12 pr-4 py-4 bg-[#1e293b] border border-slate-600 rounded-2xl text-white placeholder-slate-400 focus:outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-400/20"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-base font-bold text-slate-200 mb-3">
                        Email address <span className="text-red-400">*</span>
                      </label>
                      <div className="relative">
                        <EnvelopeIcon className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-slate-400" />
                        <input
                          type="email"
                          name="email"
                          value={formData.email}
                          onChange={handleInputChange}
                          placeholder="Enter your email address"
                          required
                          className="form-input w-full pl-12 pr-4 py-4 bg-[#1e293b] border border-slate-600 rounded-2xl text-white placeholder-slate-400 focus:outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-400/20"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-base font-bold text-slate-200 mb-3">
                        Phone number <span className="text-red-400">*</span>
                      </label>
                      <div className="flex">
                        <div className="flex items-center px-4 py-4 bg-[#1e293b] border border-r-0 border-slate-600 rounded-l-2xl">
                          <PhoneIcon className="w-5 h-5 text-slate-400 mr-2" />
                          <span className="text-slate-300">+91</span>
                          <ChevronDownIcon className="w-4 h-4 text-slate-400 ml-2" />
                        </div>
                        <input
                          type="tel"
                          name="phoneNumber"
                          value={formData.phoneNumber}
                          onChange={handleInputChange}
                          placeholder="Enter phone number"
                          required
                          className="form-input flex-1 px-4 py-4 bg-[#1e293b] border border-slate-600 rounded-r-2xl text-white placeholder-slate-400 focus:outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-400/20"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-base font-bold text-slate-200 mb-3">
                        Country <span className="text-red-400">*</span>
                      </label>
                      <div className="relative">
                        <MapPinIcon className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-slate-400" />
                        <select
                          name="country"
                          value={formData.country}
                          onChange={handleInputChange}
                          required
                          className="form-input w-full pl-12 pr-12 py-4 bg-[#1e293b] border border-slate-600 rounded-2xl text-white focus:outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-400/20 appearance-none"
                        >
                          <option value="" className="bg-[#1e293b]">Choose country</option>
                          <option value="in" className="bg-[#1e293b]">India</option>
                          <option value="us" className="bg-[#1e293b]">United States</option>
                          <option value="ca" className="bg-[#1e293b]">Canada</option>
                          <option value="uk" className="bg-[#1e293b]">United Kingdom</option>
                        </select>
                        <ChevronDownIcon className="absolute right-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-slate-400 pointer-events-none" />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div>
                        <label className="block text-base font-bold text-slate-200 mb-3">City</label>
                        <input
                          type="text"
                          name="city"
                          value={formData.city}
                          onChange={handleInputChange}
                          placeholder="Enter city"
                          className="form-input w-full px-4 py-4 bg-[#1e293b] border border-slate-600 rounded-2xl text-white placeholder-slate-400 focus:outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-400/20"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-base font-bold text-slate-200 mb-3">State</label>
                        <input
                          type="text"
                          name="state"
                          value={formData.state}
                          onChange={handleInputChange}
                          placeholder="Enter state"
                          className="form-input w-full px-4 py-4 bg-[#1e293b] border border-slate-600 rounded-2xl text-white placeholder-slate-400 focus:outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-400/20"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-base font-bold text-slate-200 mb-3">PIN Code</label>
                        <input
                          type="text"
                          name="zipCode"
                          value={formData.zipCode}
                          onChange={handleInputChange}
                          placeholder="Enter PIN code"
                          className="form-input w-full px-4 py-4 bg-[#1e293b] border border-slate-600 rounded-2xl text-white placeholder-slate-400 focus:outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-400/20"
                        />
                      </div>
                    </div>

                    <div className="flex items-start space-x-3 pt-6">
                      <input
                        type="checkbox"
                        id="terms"
                        checked={agreedToTerms}
                        onChange={(e) => setAgreedToTerms(e.target.checked)}
                        className="w-5 h-5 text-blue-600 bg-[#1e293b] border-slate-600 rounded focus:ring-blue-500 focus:ring-2 mt-1"
                      />
                      <label htmlFor="terms" className="text-slate-300 leading-relaxed">
                        I have read and agree to the{' '}
                        <span className="text-blue-400 underline hover:text-blue-300 cursor-pointer">
                          Terms and Conditions
                        </span>{' '}
                        and{' '}
                        <span className="text-blue-400 underline hover:text-blue-300 cursor-pointer">
                          Privacy Policy
                        </span>.
                      </label>
                    </div>
                  </div>
                </div>
              </div>

              {/* Right Column - Order Summary */}
              <div className="bg-gradient-to-br from-[#0f172a] to-[#1e293b] rounded-3xl p-8 shadow-2xl border border-slate-600/30 h-fit sticky top-8">
                <h3 className="text-2xl font-bold mb-8 flex items-center">
                  <CubeIcon className="w-7 h-7 mr-3 text-purple-400" />
                  Order Summary
                </h3>
                
                {/* Cart Items */}
                <div className="space-y-6 mb-8">
                  {cartItems.map((item, index) => (
                    <div key={index} className="flex items-center space-x-4 p-4 bg-[#1e293b] rounded-2xl border border-slate-600/30">
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-20 h-20 rounded-2xl object-cover shadow-lg border-2 border-slate-600"
                      />
                      <div className="flex-1">
                        <h4 className="font-bold text-white text-base mb-1 line-clamp-2">{item.name}</h4>
                        <div className="flex items-center space-x-2 mb-1">
                          <div className="flex items-center bg-green-600 text-white px-2 py-1 rounded-md text-xs font-bold">
                            <span>4.1</span>
                            <StarIcon className="w-3 h-3 ml-1 fill-current" />
                          </div>
                          <span className="text-slate-400 text-xs">(2.8k reviews)</span>
                        </div>
                        <p className="text-slate-400 text-sm">Quantity: {item.quantity}</p>
                      </div>
                      <p className="font-bold text-white text-lg">₹{item.price.toLocaleString()}</p>
                    </div>
                  ))}
                </div>

                {/* Discount Code */}
                <div className="mb-8">
                  <div className="flex space-x-3">
                    <input
                      type="text"
                      name="discountCode"
                      value={formData.discountCode}
                      onChange={handleInputChange}
                      placeholder="Enter discount code"
                      className="flex-1 px-4 py-3 bg-[#1e293b] border border-slate-600 rounded-2xl text-white placeholder-slate-400 focus:outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-400/20"
                    />
                    <button 
                      type="button"
                      className="px-6 py-3 bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white font-bold rounded-2xl transition-all duration-300 transform hover:scale-105"
                    >
                      Apply
                    </button>
                  </div>
                </div>

                {/* Order Summary */}
                <div className="space-y-4 mb-8 p-6 bg-[#1e293b] rounded-2xl border border-slate-600/30">
                  <div className="flex justify-between text-slate-300">
                    <span>Subtotal</span>
                    <span className="font-medium">₹{subtotal.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-slate-300">
                    <span>Shipping</span>
                    <span className="font-medium text-green-400">Free</span>
                  </div>
                  <div className="flex justify-between text-slate-300">
                    <span>Discount</span>
                    <span className="font-medium text-green-400">-₹{Math.abs(discount).toLocaleString()}</span>
                  </div>
                  <hr className="border-slate-600" />
                  <div className="flex justify-between items-center">
                    <span className="text-xl font-bold text-white">Total</span>
                    <span className="text-2xl font-bold bg-gradient-to-r from-green-400 to-emerald-500 bg-clip-text text-transparent">
                      ₹{total.toLocaleString()}
                    </span>
                  </div>
                </div>

                {/* Pay Now Button */}
                <button 
                  type="submit"
                  className="checkout-btn w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white py-5 rounded-2xl font-bold text-xl transition-all duration-300 transform shadow-2xl mb-6 flex items-center justify-center space-x-3 disabled:opacity-50 disabled:cursor-not-allowed"
                  disabled={!agreedToTerms}
                >
                  <CreditCardIcon className="w-6 h-6" />
                  <span>Complete Payment</span>
                </button>

                {/* Security Notice */}
                <div className="bg-[#1e293b] rounded-2xl p-6 border border-slate-600/30">
                  <div className="flex items-center space-x-3 mb-3">
                    <div className="w-10 h-10 bg-gradient-to-r from-green-500 to-emerald-600 rounded-full flex items-center justify-center">
                      <ShieldCheckIcon className="w-5 h-5 text-white" />
                    </div>
                    <span className="font-bold text-white">Secure Checkout</span>
                  </div>
                  <p className="text-slate-400 text-sm leading-relaxed mb-4">
                    Your payment information is encrypted and secure. We use industry-standard SSL encryption to protect your financial and personal data during every transaction.
                  </p>
                  <div className="flex items-center space-x-4">
                    <div className="glass-effect rounded-lg px-3 py-2">
                      <span className="text-xs text-slate-300 font-medium">SSL Encrypted</span>
                    </div>
                    <div className="glass-effect rounded-lg px-3 py-2">
                      <span className="text-xs text-slate-300 font-medium">PCI Compliant</span>
                    </div>
                    <div className="glass-effect rounded-lg px-3 py-2">
                      <span className="text-xs text-slate-300 font-medium">256-bit Security</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </form>

          {/* Payment Methods */}
          <div className="mt-16 bg-gradient-to-r from-[#0f172a] to-[#1e293b] rounded-3xl p-8 border border-slate-600/30 shadow-2xl">
            <h3 className="text-2xl font-bold text-white mb-8 text-center flex items-center justify-center">
              <CreditCardIcon className="w-8 h-8 mr-3 text-blue-400" />
              Accepted Payment Methods
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              <div className="bg-[#1e293b] border border-slate-600 rounded-2xl px-6 py-4 text-center">
                <span className="text-slate-300 font-medium">💳 Credit Cards</span>
              </div>
              <div className="bg-[#1e293b] border border-slate-600 rounded-2xl px-6 py-4 text-center">
                <span className="text-slate-300 font-medium">💳 Debit Cards</span>
              </div>
              <div className="bg-[#1e293b] border border-slate-600 rounded-2xl px-6 py-4 text-center">
                <span className="text-slate-300 font-medium">📱 UPI</span>
              </div>
              <div className="bg-[#1e293b] border border-slate-600 rounded-2xl px-6 py-4 text-center">
                <span className="text-slate-300 font-medium">🏦 Net Banking</span>
              </div>
              <div className="bg-[#1e293b] border border-slate-600 rounded-2xl px-6 py-4 text-center">
                <span className="text-slate-300 font-medium">💰 Wallets</span>
              </div>
            </div>
          </div>
        </div>

        {/* Enhanced Footer */}
        <footer className="w-full bg-gradient-to-b from-[#0f172a] to-[#020617] border-t border-slate-600/30 mt-16">
          <div className="max-w-7xl mx-auto px-4 py-16">
            {/* Main Footer Content */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
              {/* Brand Section */}
              <div className="space-y-6">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center shadow-xl">
                    <CubeIcon className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="text-3xl font-bold text-white">StyleLoom</h3>
                </div>
                <p className="text-slate-400 text-base leading-relaxed">
                  Your ultimate destination for fashion, electronics, and lifestyle products. 
                  Quality guaranteed, delivered fast.
                </p>
                <div className="flex space-x-4">
                  <button className="social-icon w-12 h-12 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 rounded-2xl flex items-center justify-center transition-all">
                    <Facebook className="w-6 h-6 text-white" />
                  </button>
                  <button className="social-icon w-12 h-12 bg-gradient-to-r from-blue-400 to-blue-500 hover:from-blue-500 hover:to-blue-600 rounded-2xl flex items-center justify-center transition-all">
                    <Twitter className="w-6 h-6 text-white" />
                  </button>
                  <button className="social-icon w-12 h-12 bg-gradient-to-r from-pink-500 to-red-500 hover:from-pink-600 hover:to-red-600 rounded-2xl flex items-center justify-center transition-all">
                    <Instagram className="w-6 h-6 text-white" />
                  </button>
                  <button className="social-icon w-12 h-12 bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 rounded-2xl flex items-center justify-center transition-all">
                    <Youtube className="w-6 h-6 text-white" />
                  </button>
                </div>
              </div>

              {/* Quick Links */}
              <div className="space-y-6">
                <h4 className="text-xl font-bold text-white">Quick Links</h4>
                <div className="space-y-3">
                  <a href="/products" className="footer-link block text-slate-400 hover:text-white text-base transition-all">All Products</a>
                  <a href="/categories" className="footer-link block text-slate-400 hover:text-white text-base transition-all">Categories</a>
                  <a href="/deals" className="footer-link block text-slate-400 hover:text-white text-base transition-all">Daily Deals</a>
                  <a href="/new-arrivals" className="footer-link block text-slate-400 hover:text-white text-base transition-all">New Arrivals</a>
                  <a href="/wishlist" className="footer-link block text-slate-400 hover:text-white text-base transition-all">Wishlist</a>
                </div>
              </div>

              {/* Customer Service */}
              <div className="space-y-6">
                <h4 className="text-xl font-bold text-white">Customer Service</h4>
                <div className="space-y-3">
                  <a href="/help" className="footer-link block text-slate-400 hover:text-white text-base transition-all">Help Center</a>
                  <a href="/returns" className="footer-link block text-slate-400 hover:text-white text-base transition-all">Returns & Exchanges</a>
                  <a href="/shipping" className="footer-link block text-slate-400 hover:text-white text-base transition-all">Shipping Info</a>
                  <a href="/track" className="footer-link block text-slate-400 hover:text-white text-base transition-all">Track Your Order</a>
                  <a href="/size-guide" className="footer-link block text-slate-400 hover:text-white text-base transition-all">Size Guide</a>
                </div>
              </div>

              {/* Contact Info */}
              <div className="space-y-6">
                <h4 className="text-xl font-bold text-white">Contact Us</h4>
                <div className="space-y-4">
                  <div className="flex items-center space-x-4 text-slate-400 text-base">
                    <EnvelopeIcon className="w-5 h-5 text-blue-400" />
                    <span>support@styleloom.com</span>
                  </div>
                  <div className="flex items-center space-x-4 text-slate-400 text-base">
                    <PhoneIcon className="w-5 h-5 text-green-400" />
                    <span>+91 1800-123-4567</span>
                  </div>
                  <div className="flex items-start space-x-4 text-slate-400 text-base">
                    <MapPinIcon className="w-5 h-5 text-red-400 mt-1" />
                    <span>123 Fashion Street,<br />Mumbai, Maharashtra 400001</span>
                  </div>
                </div>
                
                {/* Newsletter */}
                <div className="mt-8">
                  <h5 className="text-base font-bold text-white mb-4">Stay Updated</h5>
                  <div className="flex space-x-3">
                    <input 
                      type="email" 
                      placeholder="Enter email" 
                      className="flex-1 px-4 py-3 bg-[#1e293b] border border-slate-600 rounded-xl text-white text-base focus:outline-none focus:border-blue-400 transition-colors placeholder-slate-400"
                    />
                    <button className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white px-6 py-3 rounded-xl font-bold transition-all">
                      Subscribe
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Payment Methods & Guarantees */}
            <div className="border-t border-slate-600/30 pt-12 mb-12">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                <div>
                  <h5 className="text-lg font-bold text-white mb-6">We Accept</h5>
                  <div className="flex flex-wrap gap-4">
                    <div className="bg-[#1e293b] border border-slate-600 rounded-xl px-4 py-3 text-slate-300 text-base">
                      💳 Visa
                    </div>
                    <div className="bg-[#1e293b] border border-slate-600 rounded-xl px-4 py-3 text-slate-300 text-base">
                      💳 Mastercard
                    </div>
                    <div className="bg-[#1e293b] border border-slate-600 rounded-xl px-4 py-3 text-slate-300 text-base">
                      📱 UPI
                    </div>
                    <div className="bg-[#1e293b] border border-slate-600 rounded-xl px-4 py-3 text-slate-300 text-base">
                      💰 COD
                    </div>
                  </div>
                </div>
                <div>
                  <h5 className="text-lg font-bold text-white mb-6">Our Guarantee</h5>
                  <div className="flex flex-wrap gap-3">
                    <div className="glass-effect rounded-xl px-4 py-3 text-slate-300 text-base">
                      ✓ 30-Day Returns
                    </div>
                    <div className="glass-effect rounded-xl px-4 py-3 text-slate-300 text-base">
                      ✓ Secure Checkout
                    </div>
                    <div className="glass-effect rounded-xl px-4 py-3 text-slate-300 text-base">
                      ✓ Free Shipping
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Bottom Footer */}
            <div className="border-t border-slate-600/30 pt-8 flex flex-col md:flex-row justify-between items-center">
              <div className="text-slate-400 text-base mb-6 md:mb-0">
                © 2025 StyleLoom. All rights reserved. Made with ❤️ in India
              </div>
              <div className="flex space-x-8 text-base">
                <a href="/privacy" className="footer-link text-slate-400 hover:text-white transition-all">Privacy Policy</a>
                <a href="/terms" className="footer-link text-slate-400 hover:text-white transition-all">Terms of Service</a>
                <a href="/cookies" className="footer-link text-slate-400 hover:text-white transition-all">Cookie Policy</a>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </>
  );
};

export default CheckoutForm;
