import React, { useState, useEffect, useRef } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
 
const HeroSection = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);
  const [progress, setProgress] = useState(0);
  const autoplayRef = useRef(null);
  const progressRef = useRef(null);
 const navigate = useNavigate();
  const clothingCategories = [
    {
      id: 1,
      title: "Men's Fashion",
      subtitle: "Up to 70% Off",
      description: "Shirts, T-shirts & more",
      image: "https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=1200&h=600&fit=crop&crop=center",
      bgColor: "from-blue-500 to-blue-700"
    },
    {
      id: 2,
      title: "Women's Ethnic",
      subtitle: "Starting ₹199",
      description: "Sarees, Kurtas & more",
      image: "https://images.unsplash.com/photo-1583391733956-6c78276477e2?w=1200&h=600&fit=crop&crop=center",
      bgColor: "from-purple-500 to-pink-600"
    },
    {
      id: 3,
      title: "Footwear",
      subtitle: "Min 40% Off",
      description: "Sports, Casual & Formal",
      image: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=1200&h=600&fit=crop&crop=center",
      bgColor: "from-green-500 to-teal-600"
    },
    {
      id: 4,
      title: "Kids Fashion",
      subtitle: "Up to 60% Off",
      description: "Clothing & Accessories",
      image: "https://images.unsplash.com/photo-1519238263530-99bdd11df2ea?w=1200&h=600&fit=crop&crop=center",
      bgColor: "from-orange-500 to-red-600"
    },
    {
      id: 5,
      title: "Accessories",
      subtitle: "Starting ₹99",
      description: "Watches, Bags & Jewelry",
      image: "https://images.unsplash.com/photo-1611652022419-a9419f74343d?w=1200&h=600&fit=crop&crop=center",
      bgColor: "from-indigo-500 to-purple-600"
    },
    {
      id: 6,
      title: "Women's Western",
      subtitle: "Flat 50% Off",
      description: "Dresses, Tops & Jeans",
      image: "https://images.unsplash.com/photo-1483985988355-763728e1935b?w=1200&h=600&fit=crop&crop=center",
      bgColor: "from-pink-500 to-rose-600"
    },
    {
      id: 7,
      title: "Sports & Fitness",
      subtitle: "Up to 80% Off",
      description: "Activewear & Gym Gear",
      image: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=1200&h=600&fit=crop&crop=center",
      bgColor: "from-cyan-500 to-blue-600"
    },
    {
      id: 8,
      title: "Winter Collection",
      subtitle: "Starting ₹299",
      description: "Jackets, Sweaters & Coats",
      image: "https://images.unsplash.com/photo-1544966503-7cc5ac882d5f?w=1200&h=600&fit=crop&crop=center",
      bgColor: "from-gray-600 to-gray-800"
    }
  ];

  // Auto-play functionality with progress bar
  useEffect(() => {
    const duration = 3000; // 3 seconds
    
    if (isAutoPlaying) {
      // Reset progress
      setProgress(0);
      
      // Progress bar animation
      progressRef.current = setInterval(() => {
        setProgress((prev) => {
          if (prev >= 100) {
            return 0;
          }
          return prev + (100 / (duration / 50)); // Update every 50ms
        });
      }, 50);
      
      // Slide change
      autoplayRef.current = setTimeout(() => {
        setCurrentSlide((prev) => (prev + 1) % clothingCategories.length);
      }, duration);
    }

    return () => {
      if (autoplayRef.current) {
        clearTimeout(autoplayRef.current);
      }
      if (progressRef.current) {
        clearInterval(progressRef.current);
      }
    };
  }, [currentSlide, isAutoPlaying, clothingCategories.length]);

  const nextSlide = () => {
    setProgress(0);
    setCurrentSlide((prev) => (prev + 1) % clothingCategories.length);
  };

  const prevSlide = () => {
    setProgress(0);
    setCurrentSlide((prev) => (prev - 1 + clothingCategories.length) % clothingCategories.length);
  };

  const goToSlide = (index) => {
    setProgress(0);
    setCurrentSlide(index);
  };

  const handleMouseEnter = () => {
    setIsAutoPlaying(false);
  };

  const handleMouseLeave = () => {
    setIsAutoPlaying(true);
  };

  return (
    <div className="w-full bg-gradient-to-r from-slate-600 via-slate-700 to-slate-800 relative overflow-hidden">
      {/* Main Carousel Container - Full Width */}
      <div 
        className="relative h-48 sm:h-64 md:h-80 lg:h-96 xl:h-[450px] overflow-hidden w-full"
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
      >
        {/* Background Decorative Elements */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          {/* Floating Golden Elements */}
          <div className="absolute top-4 right-6 sm:top-6 sm:right-10 md:top-10 md:right-20 lg:right-32 w-3 h-3 sm:w-4 sm:h-4 md:w-6 md:h-6 bg-yellow-400 rounded-full opacity-60 animate-bounce" style={{animationDelay: '0s'}}></div>
          <div className="absolute top-12 right-16 sm:top-16 sm:right-20 md:top-24 md:right-32 lg:right-48 w-2 h-2 sm:w-3 sm:h-3 md:w-4 md:h-4 bg-yellow-300 rounded-full opacity-40 animate-bounce" style={{animationDelay: '1s'}}></div>
          <div className="absolute bottom-8 right-4 sm:bottom-12 sm:right-8 md:bottom-20 md:right-16 lg:right-24 w-4 h-4 sm:w-6 sm:h-6 md:w-8 md:h-8 bg-yellow-400 rounded-full opacity-50 animate-pulse"></div>
          
          {/* Geometric Shapes */}
          <div className="absolute top-6 left-1/4 sm:left-1/3 md:left-1/2 w-8 h-8 sm:w-12 sm:h-12 md:w-20 md:h-20 border-2 border-yellow-300/30 rounded-full animate-spin" style={{animationDuration: '20s'}}></div>
          <div className="absolute bottom-6 left-8 sm:bottom-8 sm:left-10 md:bottom-16 md:left-20 lg:left-32 w-6 h-6 sm:w-8 sm:h-8 md:w-12 md:h-12 border border-white/20 rotate-45"></div>
        </div>

        {/* Slides */}
        {clothingCategories.map((category, index) => (
          <div
            key={category.id}
            className={`absolute inset-0 transition-transform duration-500 ease-in-out ${
              index === currentSlide ? 'translate-x-0' : 
              index < currentSlide ? '-translate-x-full' : 'translate-x-full'
            }`}
          >
            <div className="w-full h-full relative overflow-hidden">
              {/* Background Image */}
              <div className="absolute inset-0">
                <img
                  src={category.image}
                  alt={category.title}
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    e.target.src = `https://via.placeholder.com/1200x600/475569/FFFFFF?text=${encodeURIComponent(category.title)}`;
                  }}
                />
                {/* Overlay for better text readability */}
                <div className="absolute inset-0 bg-black/40"></div>
                <div className={`absolute inset-0 bg-gradient-to-br ${category.bgColor} opacity-50`}></div>
              </div>

              {/* Centered Content */}
              <div className="absolute inset-0 flex items-center justify-center z-10">
                <div className="text-center text-white max-w-xs sm:max-w-sm md:max-w-md lg:max-w-lg xl:max-w-2xl px-4 sm:px-6 md:px-8">
                  <p className="text-xs sm:text-sm md:text-base opacity-90 mb-1 sm:mb-2 md:mb-3 uppercase tracking-wide">Fashion</p>
                  <h2 className="text-xl sm:text-2xl md:text-3xl lg:text-4xl xl:text-6xl font-bold mb-2 sm:mb-3 md:mb-4 leading-tight drop-shadow-lg">
                    {category.title}
                  </h2>
                  <p className="text-base sm:text-lg md:text-xl lg:text-2xl xl:text-4xl font-semibold mb-2 sm:mb-3 md:mb-4 text-yellow-200 drop-shadow-md">
                    {category.subtitle}
                  </p>
                  <p className="text-xs sm:text-sm md:text-base lg:text-lg xl:text-xl opacity-90 mb-4 sm:mb-6 md:mb-8 drop-shadow-sm">
                    {category.description}
                  </p>
                  <div className="relative"onClick={()=>navigate('/products')}>
                    <button className="bg-white text-gray-800 px-3 sm:px-4 md:px-6 lg:px-8 xl:px-10 py-2 sm:py-2.5 md:py-3 lg:py-4 xl:py-5 rounded-lg font-semibold hover:bg-yellow-100 transition-all duration-200 shadow-xl hover:shadow-2xl transform hover:scale-105 text-xs sm:text-sm md:text-base lg:text-lg" 
                    
                    >
                      Shop Now
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}

        {/* Navigation Arrows */}
        <button
          onClick={prevSlide}
          className="absolute left-2 sm:left-3 md:left-4 lg:left-6 xl:left-8 top-1/2 -translate-y-1/2 bg-white/20 backdrop-blur-sm text-white p-1 sm:p-1.5 md:p-2 lg:p-3 xl:p-4 rounded-full hover:bg-white/30 transition-all duration-200 z-20"
        >
          <ChevronLeft className="w-4 h-4 sm:w-5 sm:h-5 md:w-6 md:h-6 lg:w-7 lg:h-7 xl:w-8 xl:h-8" />
        </button>
        
        <button
          onClick={nextSlide}
          className="absolute right-2 sm:right-3 md:right-4 lg:right-6 xl:right-8 top-1/2 -translate-y-1/2 bg-white/20 backdrop-blur-sm text-white p-1 sm:p-1.5 md:p-2 lg:p-3 xl:p-4 rounded-full hover:bg-white/30 transition-all duration-200 z-20"
        >
          <ChevronRight className="w-4 h-4 sm:w-5 sm:h-5 md:w-6 md:h-6 lg:w-7 lg:h-7 xl:w-8 xl:h-8" />
        </button>
      </div>

      {/* Dot Indicators with Progress Bar */}
      <div className="flex justify-center items-center space-x-1 sm:space-x-2 md:space-x-3 py-2 sm:py-3 md:py-4 lg:py-5 bg-gradient-to-r from-slate-600 via-slate-700 to-slate-800">
        {clothingCategories.map((_, index) => (
          <button
            key={index}
            onClick={() => goToSlide(index)}
            className={`transition-all duration-200 relative overflow-hidden ${
              index === currentSlide 
                ? 'w-6 sm:w-8 md:w-10 lg:w-12 xl:w-16 h-2 sm:h-2.5 md:h-3 lg:h-3.5 xl:h-4 rounded-full bg-gray-400' 
                : 'w-2 sm:w-2.5 md:w-3 lg:w-3.5 xl:w-4 h-2 sm:h-2.5 md:h-3 lg:h-3.5 xl:h-4 rounded-full bg-gray-400 hover:bg-gray-300'
            }`}
          >
            {/* Progress bar inside the active dot */}
            {index === currentSlide && (
              <div 
                className="absolute top-0 left-0 h-full bg-blue-400 transition-all duration-75 ease-linear rounded-full"
                style={{ width: `${progress}%` }}
              />
            )}
          </button>
        ))}
      </div>

      {/* Bottom Banner */}
      <div className="bg-gradient-to-r from-slate-600 via-slate-700 to-slate-800 text-white text-center py-2 sm:py-2.5 md:py-3 lg:py-4 border-t border-slate-500/30">
        <p className="text-xs sm:text-sm md:text-base lg:text-lg font-medium px-2 sm:px-4">🎉 Free Shipping on orders above ₹499 | Easy Returns | COD Available</p>
      </div>
    </div>
  );
};

export default HeroSection;