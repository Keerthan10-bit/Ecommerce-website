import React from 'react';
import { Link, useNavigate } from 'react-router-dom';

const Nav = ({ cartItems = [] }) => {
  const navigate = useNavigate();

  // Calculate total quantity of items in cart
  const totalQuantity = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <header className="bg-gray-500 py-5 relative">
      {/* Dashed line decoration */}
      <div className="absolute bottom-0 left-12 right-12 h-px bg-gradient-to-r from-gray-400 via-transparent via-transparent to-gray-400 bg-[length:10px_1px] bg-repeat-x"></div>
      
      <nav className="max-w-6xl mx-auto px-12 flex justify-between items-center">
        {/* Left navigation */}
        <div className="flex gap-0">
          <Link
            to="/"
            className="text-white px-6 py-3 text-sm font-medium no-underline transition-all duration-200 ease-in-out bg-gray-700 rounded-lg"
          >
            Home
          </Link>
          <Link
            to="/products"
            className="text-white px-6 py-3 ml-2.5 text-sm font-medium no-underline transition-all duration-200 ease-in-out border-2 border-dashed border-gray-400 rounded-lg hover:bg-gray-600"
          >
            Products
          </Link>
        </div>

        {/* Logo */}
        <div className="text-white text-2xl font-normal tracking-wider cursor-pointer" onClick={() => navigate('/')}>
          Style Loom
        </div>

        {/* Right navigation */}
        <div className="flex gap-4 items-center relative">
          <button
            onClick={() => navigate('/cart')}
            className="bg-gray-700 text-white p-3 rounded-lg text-lg w-12 h-12 flex items-center justify-center transition-all duration-200 ease-in-out hover:bg-gray-800 relative"
            aria-label="Go to cart"
          >
            🛒
            {totalQuantity > 0 && (
              <span className="absolute -top-1 -right-1 bg-red-600 text-white rounded-full text-xs w-5 h-5 flex items-center justify-center font-bold">
                {totalQuantity}
              </span>
            )}
          </button>
          <Link
            to="/aboutus"
            className="bg-amber-300 text-gray-800 px-6 py-3 rounded-lg text-sm font-medium no-underline transition-all duration-200 ease-in-out hover:bg-amber-400"
          >
            About us
          </Link>
        </div>
      </nav>
    </header>
  );
};

export default Nav;
