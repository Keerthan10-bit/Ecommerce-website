import React from 'react'
import HeroSection from './HeroSection'

import ProductGrid from './ProductGrid'
import StyleLoomBanner from './StyleLoomBanner'
import LastBanner from './LastBanner'
import StyleLoomFooter from './StyleLoomFooter'
import Socials from './Socials'
import Nav from './Nav'
const Home = () => {
  return (
   <>
   
   
    <Nav/>
    <HeroSection/>
    <ProductGrid/>
    <StyleLoomBanner/>
    <LastBanner/>
    <Socials/>
    <StyleLoomFooter/>
   </>
  )
}

export default Home