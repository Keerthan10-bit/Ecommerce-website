import React, { useState } from 'react';

const NavigationStyle = () => {
  const [hoveredCategory, setHoveredCategory] = useState(null);

  const allCategories = {
    "Men": {
      "Clothing": ['Shirts', 'T-Shirts'],
      "Footwear": ['Casual Shoes', 'Formal Shoes'],
      "Accessories": ['Watches', 'Belts']
    },
    "Women": {
      "Clothing": ['Sarees', 'Kurtas'],
      "Footwear": ['Heels', 'Flats'],
      "Beauty": ['Makeup', 'Skincare']
    },
    "Kids": {
      "Boys": ['Boys Clothing', 'Boys Shoes'],
      "Girls": ['Girls Clothing', 'Girls Shoes'],
      "Accessories": ['Bags', 'Watches']
    },
    "Accessories": {
      "Bags": ['Handbags', 'Backpacks'],
      "Jewelry": ['Earrings', 'Necklaces'],
      "Watches": ['Smart Watches', 'Analog Watches']
    }
  };

  const handleCategoryClick = (mainCategory, subCategory, item) => {
    if (item === 'more') {
      console.log(`Navigate to ${mainCategory} ${subCategory} page to see all items`);
    } else {
      console.log(`Navigating to: ${mainCategory} > ${subCategory} > ${item}`);
    }
  };

  return (
    <div className="w-full bg-gray-600">
      {/* Simple Navigation Bar */}
      <nav className="w-full px-2 sm:px-4 lg:px-8 py-2 sm:py-4 bg-white border-b border-gray-200">
        <div className="flex items-center justify-center sm:justify-start space-x-2 sm:space-x-4 lg:space-x-8">
          {/* Navigation Items */}
          <div className="flex items-center space-x-2 sm:space-x-4 lg:space-x-8 flex-wrap justify-center sm:justify-start">
            {Object.keys(allCategories).map((mainCategory, index) => (
              <div 
                key={index}
                className="relative"
                onMouseEnter={() => setHoveredCategory(mainCategory)}
                onMouseLeave={() => setHoveredCategory(null)}
              >
                <button className="flex items-center space-x-1 text-gray-700 hover:text-gray-900 font-medium py-1 sm:py-2 transition-colors duration-200 text-sm sm:text-base">
                  <span>{mainCategory}</span>
                  <svg 
                    className={`w-3 h-3 sm:w-4 sm:h-4 transition-transform duration-200 ${hoveredCategory === mainCategory ? 'rotate-180' : ''}`}
                    fill="none" 
                    stroke="currentColor" 
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </button>

                {/* Dropdown Menu */}
                {hoveredCategory === mainCategory && (
                  <div className="absolute top-full left-0 mt-1 w-screen max-w-xs sm:max-w-lg md:max-w-2xl lg:max-w-4xl bg-white shadow-2xl border border-gray-200 rounded-lg z-50 transform transition-all duration-300 ease-out -ml-2 sm:ml-0">
                    {/* Header */}
                    <div className="bg-gradient-to-r from-blue-50 to-indigo-50 px-2 sm:px-4 md:px-6 py-2 sm:py-3 md:py-4 border-b border-gray-200 rounded-t-lg">
                      <h2 className="text-sm sm:text-base md:text-lg font-semibold text-gray-800">{mainCategory} Categories</h2>
                      <p className="text-xs text-gray-600 mt-1 hidden sm:block">Discover fashion for {mainCategory.toLowerCase()}</p>
                    </div>

                    {/* Categories Grid */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2 sm:gap-4 md:gap-6 p-2 sm:p-4 md:p-6">
                      {Object.entries(allCategories[mainCategory]).map(([subCategory, items], subIndex) => (
                        <div key={subIndex} className="space-y-2 sm:space-y-3">
                          {/* Category Header */}
                          <div className="border-b-2 border-blue-100 pb-1 sm:pb-2">
                            <h3 className="font-bold text-gray-900 text-xs sm:text-sm md:text-base text-blue-800">
                              {subCategory}
                            </h3>
                          </div>

                          {/* Category Items */}
                          <ul className="space-y-1">
                            {items.map((item, itemIndex) => (
                              <li key={itemIndex}>
                                <button 
                                  onClick={() => handleCategoryClick(mainCategory, subCategory, item)}
                                  className="text-gray-600 hover:text-blue-600 hover:bg-blue-50 text-xs sm:text-sm block py-1 sm:py-1.5 px-1 sm:px-2 rounded-md transition-all duration-200 hover:translate-x-1 w-full text-left hover:shadow-sm"
                                >
                                  {item}
                                </button>
                              </li>
                            ))}
                          </ul>

                          {/* More Link */}
                          <div className="pt-1 sm:pt-2 border-t border-gray-100">
                            <button 
                              onClick={() => handleCategoryClick(mainCategory, subCategory, 'more')}
                              className="text-blue-600 hover:text-blue-700 font-medium text-xs sm:text-sm flex items-center transition-colors duration-200"
                            >
                              More
                              <svg className="w-2 h-2 sm:w-3 sm:h-3 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                              </svg>
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Bottom accent */}
                    <div className="bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 h-1 rounded-b-lg"></div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </nav>
    </div>
  );
};

export default NavigationStyle;