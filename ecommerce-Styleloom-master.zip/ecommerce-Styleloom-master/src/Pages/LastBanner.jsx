import React from 'react';

const LastBanner = () => {
  return (
    <div className="w-full bg-gradient-to-r from-slate-600 via-slate-700 to-slate-800 relative overflow-hidden min-h-[300px] sm:min-h-[400px] lg:min-h-[500px]">
      {/* Main Container */}
      <div className="max-w-7xl mx-auto h-full">
        <div className="flex items-center justify-between px-4 sm:px-6 md:px-8 lg:px-12 xl:px-16 py-8 sm:py-12 md:py-16 lg:py-20 h-full">
          {/* Left Content - Large Logo covering entire left */}
          <div className="flex-1 flex items-center h-full">
            <h1 className="text-white font-bold text-4xl sm:text-6xl md:text-7xl lg:text-8xl xl:text-9xl 2xl:text-[10rem] tracking-wide leading-tight">
              Style.Loom
            </h1>
          </div>

          {/* Right Decorative Element - Abstract curved design */}
          <div className="flex-shrink-0 ml-8 lg:ml-12 xl:ml-16">
            <div className="relative w-48 h-48 sm:w-64 sm:h-64 md:w-80 md:h-80 lg:w-96 lg:h-96 xl:w-[500px] xl:h-[500px]">
              <svg
                viewBox="0 0 400 400"
                className="w-full h-full"
                fill="none"
              >
                {/* Large outer curved shape */}
                <path
                  d="M50 350 Q50 150, 200 50 Q350 150, 350 350"
                  stroke="#d4b896"
                  strokeWidth="40"
                  fill="none"
                  strokeLinecap="round"
                />
                
                {/* Inner curved shape */}
                <path
                  d="M80 320 Q80 180, 200 80 Q320 180, 320 320"
                  stroke="#d4b896"
                  strokeWidth="30"
                  fill="none"
                  strokeLinecap="round"
                />
                
                {/* Additional curved lines for depth */}
                <path
                  d="M110 290 Q110 210, 200 110 Q290 210, 290 290"
                  stroke="#c9a876"
                  strokeWidth="25"
                  fill="none"
                  strokeLinecap="round"
                />
                
                {/* Small circle at top center */}
                <circle cx="200" cy="120" r="25" fill="#d4b896" />
                <circle cx="200" cy="120" r="18" fill="#c9a876" />
                
                {/* Additional decorative curved elements */}
                <path
                  d="M20 380 Q20 200, 150 80"
                  stroke="#d4b896"
                  strokeWidth="20"
                  fill="none"
                  strokeLinecap="round"
                  opacity="0.8"
                />
                
                <path
                  d="M380 380 Q380 200, 250 80"
                  stroke="#d4b896"
                  strokeWidth="20"
                  fill="none"
                  strokeLinecap="round"
                  opacity="0.8"
                />
                
                {/* Bottom connecting curve */}
                <path
                  d="M50 380 Q200 340, 350 380"
                  stroke="#c9a876"
                  strokeWidth="35"
                  fill="none"
                  strokeLinecap="round"
                />
              </svg>
            </div>
          </div>
        </div>
      </div>
      
    </div>
    
  );
};

export default LastBanner;