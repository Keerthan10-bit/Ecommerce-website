import React, { useState } from 'react';
import { ChevronDownIcon, ChevronUpIcon, MagnifyingGlassIcon } from '@heroicons/react/24/outline';

const Help = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [expandedFaq, setExpandedFaq] = useState(null);

  const categories = [
    {
      title: 'Getting Started',
      icon: '🚀',
      articles: ['How to create an account', 'Setting up your profile', 'First steps guide']
    },
    {
      title: 'Orders & Shipping',
      icon: '📦',
      articles: ['Track your order', 'Shipping information', 'Return policy', 'Size guide']
    },
    {
      title: 'Account & Billing',
      icon: '💳',
      articles: ['Update payment method', 'Manage subscriptions', 'Invoice questions', 'Refund process']
    },
    {
      title: 'StyleLoom Features',
      icon: '👕',
      articles: ['Product customization', 'Style recommendations', 'Wishlist management', 'Reviews & ratings']
    }
  ];

  const faqs = [
    {
      question: 'How do I track my StyleLoom order?',
      answer: 'Once your order is shipped, you\'ll receive a tracking number via email. You can also check your order status in your account dashboard.'
    },
    {
      question: 'What is StyleLoom\'s return policy?',
      answer: 'We offer a 30-day return policy for unworn items with original tags. Returns are free and easy through our online portal.'
    },
    {
      question: 'How do I find my size?',
      answer: 'Use our interactive size guide available on each product page. We also offer virtual fitting recommendations based on your measurements.'
    },
    {
      question: 'Can I customize my clothing items?',
      answer: 'Yes! StyleLoom offers various customization options including colors, fits, and personalization. Look for the "Customize" button on eligible products.'
    },
    {
      question: 'How do I contact StyleLoom support?',
      answer: 'You can reach us via email at support@styleloom.com, use our live chat, or call our customer service hotline during business hours.'
    }
  ];

  const toggleFaq = (index) => {
    setExpandedFaq(expandedFaq === index ? null : index);
  };

  const filteredCategories = categories.filter(category =>
    category.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    category.articles.some(article => article.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const filteredFaqs = faqs.filter(faq =>
    faq.question.toLowerCase().includes(searchTerm.toLowerCase()) ||
    faq.answer.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-slate-900">
      {/* Header */}
      <div className="bg-slate-800 border-b border-slate-700">
        <div className="max-w-4xl mx-auto px-4 py-16 text-center">
          {/* StyleLoom Logo/Brand */}
          <div className="flex items-center justify-center mb-6">
            <div className="bg-blue-600 rounded-lg p-2 mr-3">
              <svg className="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 24 24">
                <path d="M7 4V2C7 1.45 7.45 1 8 1H16C16.55 1 17 1.45 17 2V4H20C20.55 4 21 4.45 21 5S20.55 6 20 6H19V19C19 20.1 18.1 21 17 21H7C5.9 21 5 20.1 5 19V6H4C3.45 6 3 5.55 3 5S3.45 4 4 4H7ZM9 3V4H15V3H9ZM7 6V19H17V6H7Z"/>
              </svg>
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white">StyleLoom</h1>
              <p className="text-sm text-slate-400">Help Center</p>
            </div>
          </div>
          
          <h2 className="text-3xl font-bold mb-4 text-white">How can we help you?</h2>
          <p className="text-lg mb-8 text-slate-300">Search our help center or browse categories below</p>
          
          {/* Search Bar */}
          <div className="relative max-w-2xl mx-auto">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <MagnifyingGlassIcon className="h-5 w-5 text-slate-400" />
            </div>
            <input
              type="text"
              placeholder="Search for help articles..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-3 rounded-lg bg-slate-700 border border-slate-600 text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-12">
        {/* Categories Section */}
        <section className="mb-16">
          <h3 className="text-2xl font-bold text-white mb-8">Browse by Category</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredCategories.map((category, index) => (
              <div key={index} className="bg-slate-800 rounded-lg border border-slate-700 p-6 hover:bg-slate-750 transition-colors">
                <div className="flex items-center mb-4">
                  <span className="text-2xl mr-3">{category.icon}</span>
                  <h4 className="text-lg font-semibold text-white">{category.title}</h4>
                </div>
                <ul className="space-y-2">
                  {category.articles.map((article, articleIndex) => (
                    <li key={articleIndex}>
                      <a href="#" className="text-blue-400 hover:text-blue-300 hover:underline transition-colors">
                        {article}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </section>

        {/* FAQ Section */}
        <section className="mb-16">
          <h3 className="text-2xl font-bold text-white mb-8">Frequently Asked Questions</h3>
          <div className="space-y-4">
            {filteredFaqs.map((faq, index) => (
              <div key={index} className="bg-slate-800 rounded-lg border border-slate-700 overflow-hidden">
                <button
                  onClick={() => toggleFaq(index)}
                  className="w-full px-6 py-4 text-left flex justify-between items-center hover:bg-slate-750 focus:outline-none focus:bg-slate-750 transition-colors"
                >
                  <span className="font-medium text-white">{faq.question}</span>
                  {expandedFaq === index ? (
                    <ChevronUpIcon className="h-5 w-5 text-slate-400" />
                  ) : (
                    <ChevronDownIcon className="h-5 w-5 text-slate-400" />
                  )}
                </button>
                {expandedFaq === index && (
                  <div className="px-6 pb-4 border-t border-slate-700">
                    <p className="text-slate-300 pt-4">{faq.answer}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </section>

        {/* Contact Section */}
        <section className="bg-slate-800 rounded-lg border border-slate-700 p-8 text-center">
          <h3 className="text-2xl font-bold text-white mb-4">Still need help?</h3>
          <p className="text-slate-300 mb-6">Can't find what you're looking for? Our StyleLoom support team is here to help.</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors font-medium">
              Contact Support
            </button>
            <button className="bg-slate-700 text-slate-200 px-6 py-3 rounded-lg hover:bg-slate-600 transition-colors font-medium border border-slate-600">
              Live Chat
            </button>
          </div>
        </section>
      </div>
    </div>
  );
};

export default Help;
