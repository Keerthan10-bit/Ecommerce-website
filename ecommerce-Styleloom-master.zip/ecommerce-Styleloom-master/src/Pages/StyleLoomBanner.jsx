import React from 'react';

const StyleLoomBanner = () => {
  return (
    <div className="w-full bg-gradient-to-r from-slate-600 via-slate-700 to-slate-800 relative overflow-hidden">
      {/* Main Content Container */}
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between px-4 sm:px-6 md:px-8 lg:px-12 xl:px-16 py-8 sm:py-12 lg:py-16 2xl:py-20">
          {/* Left Content */}
          <div className="flex-1 max-w-none lg:max-w-2xl xl:max-w-3xl 2xl:max-w-4xl">
            {/* Navigation */}
            <nav className="flex gap-6 sm:gap-8 md:gap-10 mb-6 sm:mb-8 text-xs sm:text-sm text-white/80">
              <a href="#" className="hover:text-white transition-colors">Home</a>
              <a href="#" className="hover:text-white transition-colors">Products</a>
              <a href="#" className="text-white font-medium">Style Loom</a>
            </nav>
            
            {/* Main Heading */}
            <h1 className="text-white font-bold leading-tight mb-4 sm:mb-6">
              <div className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl xl:text-6xl 2xl:text-7xl">
                THE STYLELOOM TESTIMONIAL
              </div>
              <div className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl xl:text-6xl 2xl:text-7xl">
                COLLECTION.
              </div>
            </h1>
            
            {/* Subtext */}
            <p className="text-white/90 text-sm sm:text-base lg:text-lg xl:text-xl leading-relaxed max-w-sm sm:max-w-md lg:max-w-lg xl:max-w-xl">
              At StyleLoom, our customers are the heartbeat of our brand.
            </p>
          </div>

          {/* Right Decorative Element */}
          <div className="hidden md:block flex-shrink-0 ml-6 lg:ml-8 xl:ml-12">
            <div className="relative w-32 h-32 sm:w-40 sm:h-40 md:w-48 md:h-48 lg:w-56 lg:h-56 xl:w-64 xl:h-64 2xl:w-80 2xl:h-80">
              {/* Star/Flower Shape exactly like the image */}
              <div className="absolute inset-0 flex items-center justify-center">
                <svg
                  viewBox="0 0 200 200"
                  className="w-full h-full"
                  fill="none"
                >
                  {/* Main star/flower shape with 8 rounded petals */}
                  <g transform="translate(100,100)">
                    {/* Petal 1 - Top */}
                    <ellipse cx="0" cy="-45" rx="18" ry="45" fill="#d4b896" transform="rotate(0)" />
                    {/* Petal 2 - Top Right */}
                    <ellipse cx="0" cy="-45" rx="18" ry="45" fill="#d4b896" transform="rotate(45)" />
                    {/* Petal 3 - Right */}
                    <ellipse cx="0" cy="-45" rx="18" ry="45" fill="#d4b896" transform="rotate(90)" />
                    {/* Petal 4 - Bottom Right */}
                    <ellipse cx="0" cy="-45" rx="18" ry="45" fill="#d4b896" transform="rotate(135)" />
                    {/* Petal 5 - Bottom */}
                    <ellipse cx="0" cy="-45" rx="18" ry="45" fill="#d4b896" transform="rotate(180)" />
                    {/* Petal 6 - Bottom Left */}
                    <ellipse cx="0" cy="-45" rx="18" ry="45" fill="#d4b896" transform="rotate(225)" />
                    {/* Petal 7 - Left */}
                    <ellipse cx="0" cy="-45" rx="18" ry="45" fill="#d4b896" transform="rotate(270)" />
                    {/* Petal 8 - Top Left */}
                    <ellipse cx="0" cy="-45" rx="18" ry="45" fill="#d4b896" transform="rotate(315)" />
                    
                    {/* Center circle */}
                    <circle cx="0" cy="0" r="15" fill="#c9a876" />
                  </g>
                </svg>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Mobile decorative element */}
      <div className="md:hidden absolute top-4 right-4">
        <div className="relative w-16 h-16 sm:w-20 sm:h-20">
          <svg
            viewBox="0 0 80 80"
            className="w-full h-full"
            fill="none"
          >
            <g transform="translate(40,40)">
              {/* Small star/flower for mobile */}
              <ellipse cx="0" cy="-18" rx="7" ry="18" fill="#d4b896" transform="rotate(0)" />
              <ellipse cx="0" cy="-18" rx="7" ry="18" fill="#d4b896" transform="rotate(45)" />
              <ellipse cx="0" cy="-18" rx="7" ry="18" fill="#d4b896" transform="rotate(90)" />
              <ellipse cx="0" cy="-18" rx="7" ry="18" fill="#d4b896" transform="rotate(135)" />
              <ellipse cx="0" cy="-18" rx="7" ry="18" fill="#d4b896" transform="rotate(180)" />
              <ellipse cx="0" cy="-18" rx="7" ry="18" fill="#d4b896" transform="rotate(225)" />
              <ellipse cx="0" cy="-18" rx="7" ry="18" fill="#d4b896" transform="rotate(270)" />
              <ellipse cx="0" cy="-18" rx="7" ry="18" fill="#d4b896" transform="rotate(315)" />
              <circle cx="0" cy="0" r="6" fill="#c9a876" />
            </g>
          </svg>
        </div>
      </div>
        <div className="w-full border-t-2 border-dashed border-slate-400 mb-8"></div>
    </div>
  );
};

export default StyleLoomBanner;