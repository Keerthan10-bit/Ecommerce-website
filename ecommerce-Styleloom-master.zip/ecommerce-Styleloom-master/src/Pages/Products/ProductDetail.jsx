// src/Pages/ProductDetail.jsx
import React, { useState, useEffect } from 'react';
import { 
  ArrowLeft, Star, Heart, ShoppingCart, Share2, Truck, 
  RefreshCw, Shield, Plus, Minus, Search, User, ChevronLeft, ChevronRight 
} from 'lucide-react';
import { useNavigate, useParams } from 'react-router-dom';

const ProductDetail = ({ 
  cartItems = [], 
  addToCart, 
  wishlistItems = [],
  addToWishlist,
  removeFromWishlist,
  isInWishlist 
}) => {
  const navigate = useNavigate();
  const { productId } = useParams();
  const [selectedSize, setSelectedSize] = useState('M');
  const [quantity, setQuantity] = useState(1);
  const [addedToCart, setAddedToCart] = useState(false);
  const [addedToWishlist, setAddedToWishlist] = useState(false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  // Complete product data with proper category assignment
  const productData = {
    1: {
      id: 1,
      name: "HIGHLANDER Men Printed Regular Fit Cotton Shirt",
      brand: "HIGHLANDER",
      price: 599,
      originalPrice: 1299,
      discount: 54,
      rating: 4.1,
      reviews: 2847,
      images: [
        "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=500&h=500&fit=crop&crop=center",
        "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=500&h=500&fit=crop&crop=center",
        "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=500&h=500&fit=crop&crop=center"
      ],
      description: "Premium cotton shirt with modern printed design. Perfect for casual and semi-formal occasions. Comfortable fit with breathable fabric.",
      features: [
        "100% Premium Cotton",
        "Regular Fit",
        "Machine Washable",
        "Wrinkle Resistant",
        "Pre-shrunk Fabric"
      ],
      sizes: ['S', 'M', 'L', 'XL', 'XXL'],
      colors: ['Blue', 'White', 'Black'],
      category: "Men's Fashion"
    },
    2: {
      id: 2,
      name: "Campus Sutra Men Solid Casual T-Shirt",
      brand: "Campus Sutra",
      price: 329,
      originalPrice: 799,
      discount: 59,
      rating: 3.9,
      reviews: 1256,
      images: [
        "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=500&h=500&fit=crop&crop=center",
        "https://images.unsplash.com/photo-1586790170083-2f9ceadc732d?w=500&h=500&fit=crop&crop=center"
      ],
      description: "Comfortable casual t-shirt made from soft cotton blend. Perfect for everyday wear with a modern fit.",
      features: [
        "Cotton Blend Fabric",
        "Casual Fit",
        "Soft Touch",
        "Fade Resistant",
        "Easy Care"
      ],
      sizes: ['S', 'M', 'L', 'XL'],
      colors: ['Navy', 'Grey', 'White'],
      category: "Men's Fashion"
    },
    7: {
      id: 7,
      name: "Libas Women Floral Print A-Line Kurta",
      brand: "Libas",
      price: 649,
      originalPrice: 1299,
      discount: 50,
      rating: 4.2,
      reviews: 5634,
      images: [
        "https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?w=500&h=500&fit=crop&crop=center"
      ],
      description: "Beautiful floral print A-line kurta perfect for festive and casual occasions.",
      features: [
        "Cotton Fabric",
        "A-Line Fit", 
        "Floral Print",
        "3/4 Sleeves"
      ],
      sizes: ['S', 'M', 'L', 'XL', 'XXL'],
      colors: ['Pink', 'Blue', 'Green'],
      category: "Women's Fashion"
    },
    13: {
      id: 13,
      name: "ASIAN Men Wonder-13 Sports Running Shoes",
      brand: "ASIAN",
      price: 999,
      originalPrice: 1999,
      discount: 50,
      rating: 4.0,
      reviews: 12847,
      images: [
        "https://images.unsplash.com/photo-1549298916-b41d501d3772?w=500&h=500&fit=crop&crop=center"
      ],
      description: "Comfortable sports running shoes with excellent grip and cushioning.",
      features: [
        "Mesh Upper",
        "EVA Sole", 
        "Lightweight",
        "Anti-Slip"
      ],
      sizes: ['6', '7', '8', '9', '10', '11'],
      colors: ['Black', 'White', 'Blue'],
      category: "Footwear"
    },
    19: {
      id: 19,
      name: "Fire-Boltt Phoenix Pro Smart Watch",
      brand: "Fire-Boltt",
      price: 1999,
      originalPrice: 7999,
      discount: 75,
      rating: 4.0,
      reviews: 28956,
      images: [
        "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=500&h=500&fit=crop&crop=center"
      ],
      description: "Advanced smartwatch with health monitoring and fitness tracking features.",
      features: [
        "Heart Rate Monitor",
        "Fitness Tracking",
        "Water Resistant", 
        "Long Battery Life"
      ],
      sizes: ['One Size'],
      colors: ['Black', 'Silver', 'Gold'],
      category: "Electronics"
    },
    25: {
      id: 25,
      name: "WildHorn Brown Genuine Leather Wallet",
      brand: "WildHorn",
      price: 499,
      originalPrice: 1995,
      discount: 75,
      rating: 4.2,
      reviews: 8745,
      images: [
        "https://images.unsplash.com/photo-1627123424574-724758594e93?w=500&h=500&fit=crop&crop=center"
      ],
      description: "Premium genuine leather wallet with multiple card slots and cash compartments.",
      features: [
        "Genuine Leather",
        "Multiple Card Slots",
        "Cash Compartment", 
        "RFID Protection"
      ],
      sizes: ['One Size'],
      colors: ['Brown', 'Black', 'Tan'],
      category: "Accessories"
    }
    // Add more products as needed
  };

  const product = productData[productId];
  const isWishlisted = product ? isInWishlist(product.id) : false;
  const cartItemCount = cartItems.reduce((total, item) => total + item.quantity, 0);

  // **FIXED: Related products with proper category filtering**
  const relatedProducts = Object.values(productData)
    .filter(p => p.category === product?.category && p.id !== product?.id)
    .slice(0, 4);

  useEffect(() => {
    if (!product) {
      navigate('/products');
    }
  }, [product, navigate]);

  const handleAddToCart = () => {
    if (product) {
      for (let i = 0; i < quantity; i++) {
        addToCart(product);
      }
      setAddedToCart(true);
      setTimeout(() => setAddedToCart(false), 2000);
    }
  };

  const handleWishlistToggle = () => {
    if (product) {
      if (isWishlisted) {
        removeFromWishlist(product.id);
        setAddedToWishlist(false);
      } else {
        addToWishlist(product);
        setAddedToWishlist(true);
        setTimeout(() => setAddedToWishlist(false), 2000);
      }
    }
  };

  const handleBuyNow = () => {
    handleAddToCart();
    navigate('/checkout');
  };

  if (!product) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-800 mb-4">Product Not Found</h2>
          <button 
            onClick={() => navigate('/products')}
            className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors"
          >
            Back to Products
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header - keep your existing header code */}
      
      {/* Breadcrumb */}
      <div className="bg-white shadow-md border-b">
        <div className="container mx-auto px-2 sm:px-4 py-4">
          <div className="flex items-center space-x-2 text-sm text-gray-600">
            <button onClick={() => navigate('/')} className="hover:text-blue-600 font-medium">
              Home
            </button>
            <span>/</span>
            <button onClick={() => navigate('/products')} className="hover:text-blue-600 font-medium">
              Products
            </button>
            <span>/</span>
            <button onClick={() => navigate('/products')} className="hover:text-blue-600 font-medium">
              {product.category}
            </button>
            <span>/</span>
            <span className="text-gray-900 font-bold truncate">{product.name}</span>
          </div>
        </div>
      </div>

      {/* Main Product Section - keep your existing product detail code */}
      <main className="container mx-auto px-2 sm:px-4 py-6 sm:py-8">
        <div className="bg-white rounded-xl shadow-lg border overflow-hidden">
          {/* Your existing product details grid */}
          
          {/* Product Description */}
          <div className="border-t border-gray-200 p-4 sm:p-8">
            <h2 className="text-xl sm:text-2xl font-bold text-gray-800 mb-4">Product Description</h2>
            <p className="text-gray-700 leading-relaxed text-sm sm:text-base">{product.description}</p>
          </div>

          {/* **FIXED: Related Products Section** */}
          {relatedProducts.length > 0 && (
            <div className="border-t border-gray-200 p-4 sm:p-8">
              <h2 className="text-xl sm:text-2xl font-bold text-gray-800 mb-6">
                🔥 More from {product.category}
              </h2>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
                {relatedProducts.map((relatedProduct) => (
                  <div
                    key={relatedProduct.id}
                    onClick={() => navigate(`/product/${relatedProduct.id}`)}
                    className="cursor-pointer group bg-white border-2 border-gray-100 rounded-xl hover:border-blue-300 hover:shadow-xl transition-all duration-300 overflow-hidden transform hover:-translate-y-2"
                  >
                    <div className="relative">
                      <img
                        src={relatedProduct.images[0]}
                        alt={relatedProduct.name}
                        className="w-full h-36 sm:h-48 object-cover group-hover:scale-110 transition-transform duration-500"
                      />
                      {/* Wishlist button for related products */}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          if (isInWishlist(relatedProduct.id)) {
                            removeFromWishlist(relatedProduct.id);
                          } else {
                            addToWishlist(relatedProduct);
                          }
                        }}
                        className={`absolute top-2 right-2 w-8 h-8 rounded-full shadow-lg flex items-center justify-center transition-all duration-300 transform hover:scale-110 ${
                          isInWishlist(relatedProduct.id)
                            ? 'bg-red-500 text-white'
                            : 'bg-white/90 text-gray-600 hover:text-red-500'
                        }`}
                      >
                        <Heart className={`w-4 h-4 ${isInWishlist(relatedProduct.id) ? 'fill-current' : ''}`} />
                      </button>
                      {relatedProduct.discount && (
                        <div className="absolute top-2 left-2 bg-gradient-to-r from-green-500 to-emerald-500 text-white px-2 py-1 rounded-full text-xs font-bold">
                          {relatedProduct.discount}% OFF
                        </div>
                      )}
                    </div>
                    <div className="p-3 sm:p-4">
                      <h3 className="font-semibold text-gray-800 mb-2 text-xs sm:text-sm line-clamp-2 group-hover:text-blue-600 transition-colors">
                        {relatedProduct.name}
                      </h3>
                      <p className="text-gray-500 text-xs mb-2 font-medium">{relatedProduct.brand}</p>
                      <div className="flex items-center space-x-1 sm:space-x-2">
                        <span className="text-sm sm:text-base font-bold text-gray-900">₹{relatedProduct.price.toLocaleString()}</span>
                        {relatedProduct.originalPrice && (
                          <span className="text-xs sm:text-sm text-gray-500 line-through">₹{relatedProduct.originalPrice.toLocaleString()}</span>
                        )}
                      </div>
                      <div className="flex items-center mt-2">
                        <div className="flex items-center bg-green-600 text-white px-2 py-1 rounded-md text-xs font-bold mr-2">
                          <span>{relatedProduct.rating}</span>
                          <Star className="w-3 h-3 ml-1 fill-current" />
                        </div>
                        <span className="text-xs text-gray-500">({relatedProduct.reviews.toLocaleString()})</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default ProductDetail;
