// src/Pages/Products/Products.jsx
import React, { useState, useEffect, useRef } from 'react';
import {
  ChevronLeft, ChevronRight, ArrowLeft, Star, Heart, ShoppingCart,
  Share2, Truck, RefreshCw, Shield, Menu, Search, User,
  MapPin, Filter, SortAsc, Plus, Minus
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const Products = ({ cartItems = [], addToCart, productState, setProductState }) => {
  // Get state from props instead of local state
  const { currentPage, selectedCategory, selectedProduct, sortBy, priceRange } = productState;

  // Local UI state (doesn't need persistence)
  const [addedProductId, setAddedProductId] = useState(null);
  const [selectedSize, setSelectedSize] = useState('M');
  const [quantity, setQuantity] = useState(1);
  const [showCartDropdown, setShowCartDropdown] = useState(false);
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [visibleCount, setVisibleCount] = useState(6);

  const navigate = useNavigate();
  const dropdownRef = useRef(null);
  const autoplayRef = useRef(null);

  // Complete product data
  const productData = {
    "Men's Fashion": [
      {
        id: 1,
        name: "HIGHLANDER Men Printed Regular Fit Cotton Shirt",
        brand: "HIGHLANDER",
        price: 599,
        originalPrice: 1299,
        discount: 54,
        rating: 4.1,
        reviews: 2847,
        image: "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=500&h=500&fit=crop&crop=center"
      },
      {
        id: 2,
        name: "Campus Sutra Men Solid Casual T-Shirt",
        brand: "Campus Sutra",
        price: 329,
        originalPrice: 799,
        discount: 59,
        rating: 3.9,
        reviews: 1256,
        image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=500&h=500&fit=crop&crop=center"
      },
      {
        id: 3,
        name: "Levi's Men Slim Mid Rise Jeans",
        brand: "Levi's",
        price: 2199,
        originalPrice: 3199,
        discount: 31,
        rating: 4.3,
        reviews: 8965,
        image: "https://images.unsplash.com/photo-1542272604-787c3835535d?w=500&h=500&fit=crop&crop=center"
      },
      {
        id: 4,
        name: "Park Avenue Men Solid Formal Blazer",
        brand: "Park Avenue",
        price: 4999,
        originalPrice: 9999,
        discount: 50,
        rating: 4.2,
        reviews: 567,
        image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=500&h=500&fit=crop&crop=center"
      },
      {
        id: 5,
        name: "U.S. POLO ASSN. Men Solid Cotton Polo",
        brand: "U.S. POLO ASSN.",
        price: 999,
        originalPrice: 1799,
        discount: 44,
        rating: 4.0,
        reviews: 3421,
        image: "https://images.unsplash.com/photo-1586790170083-2f9ceadc732d?w=500&h=500&fit=crop&crop=center"
      },
      {
        id: 6,
        name: "Allen Solly Men Checkered Casual Shirt",
        brand: "Allen Solly",
        price: 899,
        originalPrice: 1699,
        discount: 47,
        rating: 4.1,
        reviews: 1876,
        image: "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=500&h=500&fit=crop&crop=center"
      }
    ],
    "Women's Fashion": [
      {
        id: 7,
        name: "Libas Women Floral Print A-Line Kurta",
        brand: "Libas",
        price: 649,
        originalPrice: 1299,
        discount: 50,
        rating: 4.2,
        reviews: 5634,
        image: "https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?w=500&h=500&fit=crop&crop=center"
      },
      {
        id: 8,
        name: "Akkriti by Pantaloons Women Solid Saree",
        brand: "Akkriti",
        price: 999,
        originalPrice: 2499,
        discount: 60,
        rating: 4.0,
        reviews: 2134,
        image: "https://images.unsplash.com/photo-1583391733956-6c78276477e2?w=500&h=500&fit=crop&crop=center"
      },
      {
        id: 9,
        name: "RARE Women Fit and Flare Dress",
        brand: "RARE",
        price: 799,
        originalPrice: 1599,
        discount: 50,
        rating: 3.8,
        reviews: 987,
        image: "https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=500&h=500&fit=crop&crop=center"
      },
      {
        id: 10,
        name: "Vero Moda Women Solid Casual Top",
        brand: "Vero Moda",
        price: 899,
        originalPrice: 1499,
        discount: 40,
        rating: 4.1,
        reviews: 1543,
        image: "https://images.unsplash.com/photo-1564257577817-0b8e21b2d4c8?w=500&h=500&fit=crop&crop=center"
      },
      {
        id: 11,
        name: "ONLY Women Skinny Fit Jeans",
        brand: "ONLY",
        price: 1299,
        originalPrice: 2199,
        discount: 41,
        rating: 4.2,
        reviews: 3456,
        image: "https://images.unsplash.com/photo-1584370848010-d7fe6bc767ec?w=500&h=500&fit=crop&crop=center"
      },
      {
        id: 12,
        name: "Global Desi Women Printed Tunic",
        brand: "Global Desi",
        price: 719,
        originalPrice: 1199,
        discount: 40,
        rating: 3.9,
        reviews: 876,
        image: "https://images.unsplash.com/photo-1551803091-e20673f15770?w=500&h=500&fit=crop&crop=center"
      }
    ],
    "Footwear": [
      {
        id: 13,
        name: "ASIAN Men Wonder-13 Sports Running Shoes",
        brand: "ASIAN",
        price: 999,
        originalPrice: 1999,
        discount: 50,
        rating: 4.0,
        reviews: 12847,
        image: "https://images.unsplash.com/photo-1549298916-b41d501d3772?w=500&h=500&fit=crop&crop=center"
      },
      {
        id: 14,
        name: "Campus Men FIRST Running Shoes",
        brand: "Campus",
        price: 1399,
        originalPrice: 2799,
        discount: 50,
        rating: 4.2,
        reviews: 8965,
        image: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=500&h=500&fit=crop&crop=center"
      },
      {
        id: 15,
        name: "Red Tape Men Formal Leather Shoes",
        brand: "Red Tape",
        price: 1799,
        originalPrice: 3599,
        discount: 50,
        rating: 4.1,
        reviews: 2134,
        image: "https://images.unsplash.com/photo-1614252369475-531eba835eb1?w=500&h=500&fit=crop&crop=center"
      },
      {
        id: 16,
        name: "Liberty Women Casual Sneakers",
        brand: "Liberty",
        price: 899,
        originalPrice: 1499,
        discount: 40,
        rating: 3.9,
        reviews: 1876,
        image: "https://images.unsplash.com/photo-1515347619252-60a4bf4fff4f?w=500&h=500&fit=crop&crop=center"
      },
      {
        id: 17,
        name: "Adidas Men LITE RACER Sneakers",
        brand: "Adidas",
        price: 2999,
        originalPrice: 4999,
        discount: 40,
        rating: 4.3,
        reviews: 5634,
        image: "https://images.unsplash.com/photo-1552346154-21d32810aba3?w=500&h=500&fit=crop&crop=center"
      },
      {
        id: 18,
        name: "Sparx Men Mesh Running Shoes",
        brand: "Sparx",
        price: 1199,
        originalPrice: 1999,
        discount: 40,
        rating: 4.0,
        reviews: 7854,
        image: "https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?w=500&h=500&fit=crop&crop=center"
      }
    ],
    "Electronics": [
      {
        id: 19,
        name: "Fire-Boltt Phoenix Pro Smart Watch",
        brand: "Fire-Boltt",
        price: 1999,
        originalPrice: 7999,
        discount: 75,
        rating: 4.0,
        reviews: 28956,
        image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=500&h=500&fit=crop&crop=center"
      },
      {
        id: 20,
        name: "boAt Airdopes 141 Bluetooth Earbuds",
        brand: "boAt",
        price: 1499,
        originalPrice: 4990,
        discount: 70,
        rating: 4.1,
        reviews: 15642,
        image: "https://images.unsplash.com/photo-1484704849700-f032a568e944?w=500&h=500&fit=crop&crop=center"
      },
      {
        id: 21,
        name: "Samsung Galaxy M32 Smartphone",
        brand: "Samsung",
        price: 12999,
        originalPrice: 20999,
        discount: 38,
        rating: 4.2,
        reviews: 45789,
        image: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=500&h=500&fit=crop&crop=center"
      },
      {
        id: 22,
        name: "Realme 32 inch HD Ready Smart LED TV",
        brand: "Realme",
        price: 12999,
        originalPrice: 24999,
        discount: 48,
        rating: 4.3,
        reviews: 8965,
        image: "https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?w=500&h=500&fit=crop&crop=center"
      },
      {
        id: 23,
        name: "HP 15s Laptop Intel Core i3",
        brand: "HP",
        price: 35990,
        originalPrice: 49990,
        discount: 28,
        rating: 4.1,
        reviews: 3456,
        image: "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=500&h=500&fit=crop&crop=center"
      },
      {
        id: 24,
        name: "Canon EOS 1500D DSLR Camera",
        brand: "Canon",
        price: 29999,
        originalPrice: 39995,
        discount: 25,
        rating: 4.4,
        reviews: 2134,
        image: "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=500&h=500&fit=crop&crop=center"
      }
    ],
    "Accessories": [
      {
        id: 25,
        name: "WildHorn Brown Genuine Leather Wallet",
        brand: "WildHorn",
        price: 499,
        originalPrice: 1995,
        discount: 75,
        rating: 4.2,
        reviews: 8745,
        image: "https://images.unsplash.com/photo-1627123424574-724758594e93?w=500&h=500&fit=crop&crop=center"
      },
      {
        id: 26,
        name: "Lavie Women Shoulder Bag",
        brand: "Lavie",
        price: 1299,
        originalPrice: 2599,
        discount: 50,
        rating: 4.1,
        reviews: 3456,
        image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=500&h=500&fit=crop&crop=center"
      },
      {
        id: 27,
        name: "Vincent Chase Polarized Sunglasses",
        brand: "Vincent Chase",
        price: 899,
        originalPrice: 2500,
        discount: 64,
        rating: 4.3,
        reviews: 1876,
        image: "https://images.unsplash.com/photo-1511499767150-a48a237f0083?w=500&h=500&fit=crop&crop=center"
      },
      {
        id: 28,
        name: "Fossil Men Analog Watch",
        brand: "Fossil",
        price: 4995,
        originalPrice: 8995,
        discount: 44,
        rating: 4.4,
        reviews: 987,
        image: "https://images.unsplash.com/photo-1524592094714-0f0654e20314?w=500&h=500&fit=crop&crop=center"
      },
      {
        id: 29,
        name: "Titan Raga Women Analog Watch",
        brand: "Titan",
        price: 3995,
        originalPrice: 6995,
        discount: 43,
        rating: 4.2,
        reviews: 2134,
        image: "https://images.unsplash.com/photo-1539874754764-5a96559165b0?w=500&h=500&fit=crop&crop=center"
      },
      {
        id: 30,
        name: "American Tourister Backpack",
        brand: "American Tourister",
        price: 1499,
        originalPrice: 2999,
        discount: 50,
        rating: 4.0,
        reviews: 5634,
        image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=500&h=500&fit=crop&crop=center"
      }
    ]
  };

  const categories = [
    { name: "Men's Fashion", icon: "👔", count: productData["Men's Fashion"].length, image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop&crop=center" },
    { name: "Women's Fashion", icon: "👗", count: productData["Women's Fashion"].length, image: "https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?w=400&h=400&fit=crop&crop=center" },
    { name: "Footwear", icon: "👟", count: productData["Footwear"].length, image: "https://images.unsplash.com/photo-1549298916-b41d501d3772?w=400&h=400&fit=crop&crop=center" },
    { name: "Electronics", icon: "📱", count: productData["Electronics"].length, image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400&h=400&fit=crop&crop=center" },
    { name: "Accessories", icon: "🎒", count: productData["Accessories"].length, image: "https://images.unsplash.com/photo-1627123424574-724758594e93?w=400&h=400&fit=crop&crop=center" }
  ];

  const bannerSlides = [
    {
      id: 1,
      image: "https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=1400&h=450&fit=crop&crop=center",
      alt: "Men's Fashion Sale",
      title: "Men's Fashion Sale",
      subtitle: "Up to 70% Off"
    },
    {
      id: 2,
      image: "https://images.unsplash.com/photo-1583391733956-6c78276477e2?w=1400&h=450&fit=crop&crop=center",
      alt: "Women's Ethnic Wear",
      title: "Women's Collection",
      subtitle: "Trending Now"
    },
    {
      id: 3,
      image: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=1400&h=450&fit=crop&crop=center",
      alt: "Footwear Collection",
      title: "Footwear Festival",
      subtitle: "Best Deals"
    }
  ];

  // Cart calculations
  const cartItemCount = cartItems.reduce((total, item) => total + item.quantity, 0);
  const cartSubtotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);

  // Handlers - now use setProductState instead of individual setters
  const handleClick = () => {
    navigate('/');
  };

  const handleCartClick = () => {
    navigate('/cart');
  };

  const handleCategoryClick = (categoryName) => {
    setProductState(prev => ({
      ...prev,
      selectedCategory: categoryName,
      currentPage: 'category'
    }));
  };

  const handleProductClick = (product) => {
    setProductState(prev => ({
      ...prev,
      selectedProduct: product,
      currentPage: 'product'
    }));
  };

  const handleBackToHome = () => {
    setProductState(prev => ({
      ...prev,
      currentPage: 'home',
      selectedCategory: null,
      selectedProduct: null
    }));
  };

  const handleBackToCategory = () => {
    setProductState(prev => ({
      ...prev,
      currentPage: 'category',
      selectedProduct: null
    }));
  };

  const handleAddToCart = (product, qty = 1) => {
    for (let i = 0; i < qty; i++) addToCart(product);
    setAddedProductId(product.id);
    setTimeout(() => setAddedProductId(null), 2000);
  };

  const handleSortChange = (newSort) => {
    setProductState(prev => ({
      ...prev,
      sortBy: newSort
    }));
  };

  const handlePriceRangeChange = (newRange) => {
    setProductState(prev => ({
      ...prev,
      priceRange: newRange
    }));
  };

  const getSortedProducts = (products) => {
    let sorted = [...products];
    if (priceRange !== 'all') {
      const [min, max] = priceRange.split('-').map(Number);
      sorted = sorted.filter(product => {
        if (max) return product.price >= min && product.price <= max;
        else return product.price >= min;
      });
    }
    switch (sortBy) {
      case 'price-low': return sorted.sort((a, b) => a.price - b.price);
      case 'price-high': return sorted.sort((a, b) => b.price - a.price);
      case 'rating': return sorted.sort((a, b) => b.rating - a.rating);
      case 'discount': return sorted.sort((a, b) => b.discount - a.discount);
      default: return sorted.sort((a, b) => b.reviews - a.reviews);
    }
  };

  // Carousel handlers
  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % bannerSlides.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + bannerSlides.length) % bannerSlides.length);
  };

  const nextCarouselSlide = () => {
    setCurrentIndex((prev) => 
      prev + visibleCount >= (productData[Object.keys(productData)[0]]?.length || 0) ? 0 : prev + 1
    );
  };

  const prevCarouselSlide = () => {
    setCurrentIndex((prev) => 
      prev === 0 ? Math.max(0, (productData[Object.keys(productData)[0]]?.length || 0) - visibleCount) : prev - 1
    );
  };

  // Effects
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setShowCartDropdown(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  useEffect(() => {
    if (isAutoPlaying) {
      autoplayRef.current = setTimeout(() => {
        setCurrentSlide((prev) => (prev + 1) % bannerSlides.length);
      }, 5000);
    }

    return () => {
      if (autoplayRef.current) clearTimeout(autoplayRef.current);
    };
  }, [currentSlide, isAutoPlaying, bannerSlides.length]);

  useEffect(() => {
    const updateVisibleCount = () => {
      if (window.innerWidth < 640) setVisibleCount(2);
      else if (window.innerWidth < 768) setVisibleCount(3);
      else if (window.innerWidth < 1024) setVisibleCount(4);
      else if (window.innerWidth < 1280) setVisibleCount(5);
      else setVisibleCount(6);
    };

    updateVisibleCount();
    window.addEventListener('resize', updateVisibleCount);
    return () => window.removeEventListener('resize', updateVisibleCount);
  }, []);

  // Header with cart dropdown
  const renderHeader = () => (
    <div className="bg-white shadow-md border-b sticky top-0 z-50">
      <div className="bg-blue-600 text-white">
        <div className="container mx-auto px-2 sm:px-4 py-2">
          <div className="flex justify-between items-center text-xs sm:text-sm">
            <div className="hidden sm:flex items-center space-x-4 lg:space-x-6">
              <span className="flex items-center hover:underline cursor-pointer">
                <Truck className="w-3 h-3 sm:w-4 sm:h-4 mr-1" />
                Free Delivery
              </span>
              <span className="hover:underline cursor-pointer">Return Policy</span>
              <span className="hover:underline cursor-pointer">Customer Care</span>
            </div>
            <div className="hidden sm:flex items-center space-x-4 lg:space-x-6">
              <span className="hover:underline cursor-pointer">Download App</span>
              <span className="hover:underline cursor-pointer">Become a Seller</span>
              <span className="hover:underline cursor-pointer">More</span>
            </div>
            <div className="sm:hidden text-center w-full">
              <span className="text-xs">Free Delivery & Easy Returns</span>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-2 sm:px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2 sm:space-x-4 lg:space-x-8 flex-1">
            <div className="text-lg sm:text-xl lg:text-2xl font-bold text-blue-600 hover:text-blue-700 cursor-pointer" onClick={handleClick}>
              StyleLoom
            </div>
            <div className="relative flex-1 max-w-xs sm:max-w-md lg:max-w-2xl">
              <div className="flex">
                <input
                  type="text"
                  placeholder="Search products..."
                  className="w-full px-2 sm:px-4 py-2 sm:py-2.5 text-sm border-2 border-yellow-400 rounded-l-md focus:outline-none focus:border-yellow-500"
                />
                <button className="bg-yellow-400 hover:bg-yellow-500 px-2 sm:px-4 py-2 sm:py-2.5 rounded-r-md border-2 border-yellow-400 transition-colors">
                  <Search className="text-gray-800 w-4 h-4 sm:w-5 sm:h-5" />
                </button>
              </div>
            </div>
          </div>
          <div className="flex items-center space-x-2 sm:space-x-4 lg:space-x-6">
            <div className="hidden sm:flex items-center space-x-1 hover:bg-gray-100 px-2 py-1 rounded cursor-pointer">
              <User className="w-4 h-4 sm:w-5 sm:h-5" />
              <span className="text-xs sm:text-sm font-medium">Login</span>
            </div>
            <div className="flex items-center space-x-1 hover:bg-gray-100 px-1 sm:px-2 py-1 rounded cursor-pointer">
              <Heart className="w-4 h-4 sm:w-5 sm:h-5" />
              <span className="text-xs sm:text-sm font-medium hidden sm:block">Wishlist</span>
            </div>
            
            {/* Cart with Dropdown */}
            <div 
              className="relative" 
              ref={dropdownRef}
              onMouseEnter={() => setShowCartDropdown(true)}
              onMouseLeave={() => setShowCartDropdown(false)}
            >
              <div 
                className="flex items-center space-x-1 hover:bg-gray-100 px-1 sm:px-2 py-1 rounded cursor-pointer"
                onClick={handleCartClick}
              >
                <div className="relative">
                  <ShoppingCart className="w-4 h-4 sm:w-5 sm:h-5" />
                  {cartItemCount > 0 && (
                    <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full h-4 w-4 sm:h-5 sm:w-5 flex items-center justify-center font-bold">
                      {cartItemCount > 99 ? '99+' : cartItemCount}
                    </span>
                  )}
                </div>
                <span className="text-xs sm:text-sm font-medium hidden sm:block">Cart</span>
              </div>

              {/* Cart Dropdown */}
              {showCartDropdown && (
                <div className="absolute right-0 top-full mt-2 w-72 sm:w-80 bg-white border border-gray-200 rounded-lg shadow-xl z-50">
                  <div className="p-3 sm:p-4 border-b border-gray-200">
                    <h3 className="font-semibold text-gray-800 text-sm sm:text-base">
                      Shopping Cart ({cartItemCount} items)
                    </h3>
                  </div>
                  
                  <div className="max-h-60 sm:max-h-64 overflow-y-auto">
                    {cartItems.length === 0 ? (
                      <div className="p-4 text-center text-gray-500 text-sm">
                        Your cart is empty
                      </div>
                    ) : (
                      cartItems.slice(0, 3).map((item) => (
                        <div key={item.id} className="p-3 border-b border-gray-100 flex items-center space-x-3">
                          <img 
                            src={item.image} 
                            alt={item.name}
                            className="w-10 h-10 sm:w-12 sm:h-12 object-cover rounded"
                          />
                          <div className="flex-1 min-w-0">
                            <p className="text-xs sm:text-sm font-medium text-gray-800 truncate">
                              {item.name}
                            </p>
                            <p className="text-xs text-gray-500">
                              ₹{item.price} × {item.quantity}
                            </p>
                          </div>
                          <div className="text-xs sm:text-sm font-semibold text-gray-800">
                            ₹{item.price * item.quantity}
                          </div>
                        </div>
                      ))
                    )}
                    
                    {cartItems.length > 3 && (
                      <div className="p-3 text-center text-sm text-gray-500">
                        +{cartItems.length - 3} more items
                      </div>
                    )}
                  </div>
                  
                  {cartItems.length > 0 && (
                    <div className="p-3 sm:p-4 border-t border-gray-200">
                      <div className="flex justify-between items-center mb-3">
                        <span className="font-semibold text-gray-800 text-sm">Subtotal:</span>
                        <span className="font-bold text-base sm:text-lg text-gray-800">₹{cartSubtotal}</span>
                      </div>
                      <button 
                        onClick={handleCartClick}
                        className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-lg font-medium transition-colors text-sm"
                      >
                        View Cart & Checkout
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  // Hero Carousel
  const renderHeroCarousel = () => (
    <div className="relative h-48 sm:h-64 md:h-80 lg:h-96 xl:h-[450px] bg-gradient-to-r from-blue-100 to-purple-100 overflow-hidden">
      <div 
        className="relative w-full h-full"
        onMouseEnter={() => setIsAutoPlaying(false)}
        onMouseLeave={() => setIsAutoPlaying(true)}
      >
        {bannerSlides.map((slide, index) => (
          <div
            key={slide.id}
            className={`absolute inset-0 transition-all duration-700 ${
              index === currentSlide ? 'opacity-100 scale-100' : 'opacity-0 scale-105'
            }`}
          >
            <img
              src={slide.image}
              alt={slide.alt}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-black/40 to-transparent"></div>
            <div className="absolute left-4 sm:left-8 top-1/2 -translate-y-1/2 text-white">
              <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold mb-1 sm:mb-2">{slide.title}</h2>
              <p className="text-base sm:text-lg md:text-xl lg:text-2xl font-medium opacity-90">{slide.subtitle}</p>
            </div>
          </div>
        ))}

        <button
          onClick={prevSlide}
          className="absolute left-2 sm:left-6 top-1/2 -translate-y-1/2 w-10 h-10 sm:w-14 sm:h-14 bg-white/90 hover:bg-white rounded-full shadow-2xl flex items-center justify-center transition-all z-10 backdrop-blur-sm"
        >
          <ChevronLeft className="w-5 h-5 sm:w-7 sm:h-7 text-gray-700" />
        </button>
        
        <button
          onClick={nextSlide}
          className="absolute right-2 sm:right-6 top-1/2 -translate-y-1/2 w-10 h-10 sm:w-14 sm:h-14 bg-white/90 hover:bg-white rounded-full shadow-2xl flex items-center justify-center transition-all z-10 backdrop-blur-sm"
        >
          <ChevronRight className="w-5 h-5 sm:w-7 sm:h-7 text-gray-700" />
        </button>

        <div className="absolute bottom-3 sm:bottom-6 left-1/2 -translate-x-1/2 flex space-x-2 sm:space-x-3">
          {bannerSlides.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentSlide(index)}
              className={`w-3 h-3 sm:w-4 sm:h-4 rounded-full transition-all duration-300 ${
                index === currentSlide ? 'bg-white scale-110' : 'bg-white/60 hover:bg-white/80'
              }`}
            />
          ))}
        </div>
      </div>
    </div>
  );

  // Category Carousel
  const renderCategoryCarousel = (title, products) => (
    <div className="bg-white rounded-lg shadow-lg border mb-4 sm:mb-6 overflow-hidden">
      <div className="flex justify-between items-center p-4 sm:p-6 border-b bg-gradient-to-r from-blue-50 to-indigo-50">
        <h2 className="text-lg sm:text-xl font-bold text-gray-800">{title}</h2>
        <div className="flex space-x-2">
          <button
            onClick={prevCarouselSlide}
            className="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-white border-2 border-gray-200 hover:border-blue-400 hover:bg-blue-50 flex items-center justify-center transition-all shadow-sm"
          >
            <ChevronLeft className="w-4 h-4 sm:w-5 sm:h-5 text-gray-600" />
          </button>
          <button
            onClick={nextCarouselSlide}
            className="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-white border-2 border-gray-200 hover:border-blue-400 hover:bg-blue-50 flex items-center justify-center transition-all shadow-sm"
          >
            <ChevronRight className="w-4 h-4 sm:w-5 sm:h-5 text-gray-600" />
          </button>
        </div>
      </div>
      
      <div className="relative overflow-hidden p-2 sm:p-4">
        <div 
          className="flex transition-transform duration-500 ease-in-out"
          style={{ transform: `translateX(-${currentIndex * (100 / visibleCount)}%)` }}
        >
          {products.map((product) => {
            const isInCart = cartItems.some(item => item.id === product.id);
            return (
              <div
                key={product.id}
                className="flex-shrink-0 px-1 sm:px-2"
                style={{ width: `${100 / visibleCount}%` }}
              >
                <div className="bg-white border border-gray-200 rounded-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 overflow-hidden group">
                  <div className="relative cursor-pointer" onClick={() => handleProductClick(product)}>
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-32 sm:h-40 md:h-48 lg:h-52 object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    <div className="absolute top-2 sm:top-3 right-2 sm:right-3">
                      <button className="w-7 h-7 sm:w-9 sm:h-9 bg-white/90 backdrop-blur-sm rounded-full shadow-lg hover:shadow-xl flex items-center justify-center transition-all group-hover:bg-white">
                        <Heart className="w-3 h-3 sm:w-4 sm:h-4 text-gray-600 hover:text-red-500 transition-colors" />
                      </button>
                    </div>
                    {product.discount && (
                      <div className="absolute top-2 sm:top-3 left-2 sm:left-3 bg-gradient-to-r from-red-500 to-pink-500 text-white px-2 sm:px-3 py-1 rounded-full text-xs font-bold shadow-md">
                        {product.discount}% OFF
                      </div>
                    )}
                  </div>
                  <div className="p-2 sm:p-4">
                    <h3 className="font-semibold text-gray-800 mb-2 text-xs sm:text-sm line-clamp-2 group-hover:text-blue-600 transition-colors cursor-pointer" onClick={() => handleProductClick(product)}>
                      {product.name}
                    </h3>
                    <p className="text-gray-500 text-xs mb-2 sm:mb-3 font-medium">{product.brand}</p>
                    <div className="flex items-center mb-2 sm:mb-3">
                      <div className="flex items-center bg-green-600 text-white px-1.5 sm:px-2 py-1 rounded-md text-xs font-bold mr-2 shadow-sm">
                        <span>{product.rating}</span>
                        <Star className="w-2.5 h-2.5 sm:w-3 sm:h-3 ml-1 fill-current" />
                      </div>
                      <span className="text-xs text-gray-500 font-medium">({product.reviews.toLocaleString()})</span>
                    </div>
                    <div className="flex items-center justify-between mb-2 sm:mb-3">
                      <div className="flex items-center space-x-1 sm:space-x-2">
                        <span className="text-sm sm:text-lg font-bold text-gray-900">₹{product.price.toLocaleString()}</span>
                        {product.originalPrice && (
                          <span className="text-xs sm:text-sm text-gray-500 line-through font-medium">₹{product.originalPrice.toLocaleString()}</span>
                        )}
                      </div>
                    </div>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleAddToCart(product);
                      }}
                      className={`w-full py-1.5 sm:py-2 rounded-lg transition-all font-medium text-xs sm:text-sm ${
                        addedProductId === product.id
                          ? 'bg-green-600 text-white'
                          : isInCart
                          ? 'bg-orange-600 hover:bg-orange-700 text-white'
                          : 'bg-blue-600 hover:bg-blue-700 text-white'
                      }`}
                    >
                      {addedProductId === product.id ? 'Added!' : isInCart ? 'Add More' : 'Add to Cart'}
                    </button>
                    <p className="text-xs text-green-600 mt-1 sm:mt-2 font-semibold">✓ Free delivery</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );

  // Main Pages
  if (currentPage === 'home') {
    return (
      <div className="min-h-screen bg-gray-50">
        {renderHeader()}
        {renderHeroCarousel()}
        
        <div className="container mx-auto px-2 sm:px-4 py-4 sm:py-8">
          {/* Categories Section */}
          <div className="bg-white rounded-xl shadow-lg border mb-4 sm:mb-8 overflow-hidden">
            <div className="p-4 sm:p-6 border-b bg-gradient-to-r from-purple-50 to-blue-50">
              <h2 className="text-xl sm:text-2xl font-bold text-gray-800 flex items-center">
                <span className="mr-2 sm:mr-3">🛍️</span>
                Shop by Category
              </h2>
              <p className="text-gray-600 mt-1 text-sm sm:text-base">Discover our top categories</p>
            </div>
            <div className="p-4 sm:p-6">
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3 sm:gap-6">
                {categories.map((category) => (
                  <div
                    key={category.name}
                    onClick={() => handleCategoryClick(category.name)}
                    className="group cursor-pointer bg-white border-2 border-gray-100 rounded-xl hover:border-blue-300 hover:shadow-lg transition-all duration-300 overflow-hidden transform hover:-translate-y-1"
                  >
                    <div className="aspect-square overflow-hidden rounded-t-xl">
                      <img
                        src={category.image}
                        alt={category.name}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                      />
                    </div>
                    <div className="p-3 sm:p-4 text-center bg-gradient-to-t from-gray-50 to-white">
                      <h3 className="font-bold text-xs sm:text-sm text-gray-800 mb-1 group-hover:text-blue-600 transition-colors">{category.name}</h3>
                      <p className="text-xs text-gray-500 font-medium">{category.count}+ products</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Product Carousels */}
          {Object.entries(productData).slice(0, 3).map(([categoryName, products]) => 
            renderCategoryCarousel(`🔥 Best of ${categoryName}`, products)
          )}
        </div>
      </div>
    );
  }

  // Category Page
  if (currentPage === 'category') {
    return (
      <div className="min-h-screen bg-gray-50">
        {renderHeader()}
        
        <div className="bg-white shadow-md border-b">
          <div className="container mx-auto px-2 sm:px-4 py-4">
            <div className="flex items-center space-x-2 text-sm text-gray-600">
              <button onClick={handleBackToHome} className="hover:text-blue-600 font-medium">
                Home
              </button>
              <span>/</span>
              <span className="text-gray-900 font-bold truncate">{selectedCategory}</span>
            </div>
          </div>
        </div>

        <div className="container mx-auto px-2 sm:px-4 py-4 sm:py-6">
          <div className="flex flex-col lg:flex-row gap-4 sm:gap-6">
            {/* Filters Sidebar */}
            <div className="lg:w-72 flex-shrink-0">
              <div className="bg-white rounded-xl shadow-lg border p-4 sm:p-6 lg:sticky lg:top-24">
                <h3 className="font-bold text-gray-800 mb-4 sm:mb-6 flex items-center text-base sm:text-lg">
                  <Filter className="w-4 h-4 sm:w-5 sm:h-5 mr-2 text-blue-600" />
                  Filters
                </h3>
                
                <div className="mb-6 sm:mb-8">
                  <h4 className="font-bold text-gray-700 mb-3 sm:mb-4 text-sm uppercase tracking-wide">Price Range</h4>
                  <div className="space-y-2 sm:space-y-3">
                    {[
                      { value: 'all', label: 'All Prices', count: '2.4k' },
                      { value: '0-500', label: 'Under ₹500', count: '156' },
                      { value: '500-1000', label: '₹500 - ₹1,000', count: '324' },
                      { value: '1000-2000', label: '₹1,000 - ₹2,000', count: '891' },
                      { value: '2000-5000', label: '₹2,000 - ₹5,000', count: '567' },
                      { value: '5000', label: 'Above ₹5,000', count: '89' }
                    ].map((range) => (
                      <label key={range.value} className="flex items-center justify-between text-sm cursor-pointer hover:bg-blue-50 p-2 rounded-lg transition-colors">
                        <div className="flex items-center">
                          <input
                            type="radio"
                            name="priceRange"
                            value={range.value}
                            checked={priceRange === range.value}
                            onChange={(e) => handlePriceRangeChange(e.target.value)}
                            className="mr-3 text-blue-600"
                          />
                          <span className="font-medium">{range.label}</span>
                        </div>
                        <span className="text-gray-500 text-xs">({range.count})</span>
                      </label>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="font-bold text-gray-700 mb-3 sm:mb-4 text-sm uppercase tracking-wide">Sort By</h4>
                  <div className="space-y-2 sm:space-y-3">
                    {[
                      { value: 'popularity', label: 'Popularity', icon: '🔥' },
                      { value: 'price-low', label: 'Price: Low to High', icon: '💰' },
                      { value: 'price-high', label: 'Price: High to Low', icon: '💎' },
                      { value: 'rating', label: 'Customer Rating', icon: '⭐' },
                      { value: 'discount', label: 'Discount', icon: '🏷️' }
                    ].map((sort) => (
                      <label key={sort.value} className="flex items-center text-sm cursor-pointer hover:bg-blue-50 p-2 rounded-lg transition-colors">
                        <input
                          type="radio"
                          name="sortBy"
                          value={sort.value}
                          checked={sortBy === sort.value}
                          onChange={(e) => handleSortChange(e.target.value)}
                          className="mr-3 text-blue-600"
                        />
                        <span className="mr-2">{sort.icon}</span>
                        <span className="font-medium">{sort.label}</span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Products Grid */}
            <div className="flex-1">
              <div className="bg-white rounded-xl shadow-lg border mb-4 sm:mb-6 p-4 sm:p-6">
                <div className="flex justify-between items-center">
                  <div>
                    <h1 className="text-xl sm:text-2xl font-bold text-gray-800">{selectedCategory}</h1>
                    <p className="text-gray-600 mt-1 text-sm sm:text-base">Showing {getSortedProducts(productData[selectedCategory] || []).length} products</p>
                  </div>
                  <div className="hidden sm:flex items-center space-x-2 text-sm text-gray-600">
                    <SortAsc className="w-4 h-4" />
                    <span>Sorted by {sortBy}</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 gap-3 sm:gap-4 lg:gap-6">
                {getSortedProducts(productData[selectedCategory] || []).map((product) => (
                  <div
                    key={product.id}
                    className="cursor-pointer group bg-white border-2 border-gray-100 rounded-xl hover:border-blue-300 hover:shadow-xl transition-all duration-300 overflow-hidden transform hover:-translate-y-2"
                  >
                    <div className="relative" onClick={() => handleProductClick(product)}>
                      <img
                        src={product.image}
                        alt={product.name}
                        className="w-full h-36 sm:h-40 md:h-48 lg:h-52 object-cover group-hover:scale-110 transition-transform duration-500"
                      />
                      <div className="absolute top-2 sm:top-3 right-2 sm:right-3">
                        <button className="w-7 h-7 sm:w-9 sm:h-9 bg-white/90 backdrop-blur-sm rounded-full shadow-lg hover:shadow-xl flex items-center justify-center transition-all group-hover:bg-white">
                          <Heart className="w-3 h-3 sm:w-4 sm:h-4 text-gray-600 hover:text-red-500 transition-colors" />
                        </button>
                      </div>
                      {product.discount && (
                        <div className="absolute top-2 sm:top-3 left-2 sm:left-3 bg-gradient-to-r from-green-500 to-emerald-500 text-white px-2 sm:px-3 py-1 rounded-full text-xs font-bold shadow-md">
                          {product.discount}% OFF
                        </div>
                      )}
                    </div>
                    <div className="p-3 sm:p-4">
                      <h3 className="font-semibold text-gray-800 mb-2 text-xs sm:text-sm line-clamp-2 group-hover:text-blue-600 transition-colors" onClick={() => handleProductClick(product)}>
                        {product.name}
                      </h3>
                      <p className="text-gray-500 text-xs mb-2 sm:mb-3 font-medium">{product.brand}</p>
                      <div className="flex items-center mb-2 sm:mb-3">
                        <div className="flex items-center bg-green-600 text-white px-1.5 sm:px-2 py-1 rounded-md text-xs font-bold mr-2 shadow-sm">
                          <span>{product.rating}</span>
                          <Star className="w-2.5 h-2.5 sm:w-3 sm:h-3 ml-1 fill-current" />
                        </div>
                        <span className="text-xs text-gray-500 font-medium">({product.reviews.toLocaleString()})</span>
                      </div>
                      <div className="flex items-center justify-between mb-2 sm:mb-3">
                        <div className="flex items-center space-x-1 sm:space-x-2">
                          <span className="text-sm sm:text-lg font-bold text-gray-900">₹{product.price.toLocaleString()}</span>
                          {product.originalPrice && (
                            <span className="text-xs sm:text-sm text-gray-500 line-through font-medium">₹{product.originalPrice.toLocaleString()}</span>
                          )}
                        </div>
                      </div>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleAddToCart(product);
                        }}
                        className={`w-full py-1.5 sm:py-2 rounded-lg transition-all text-xs sm:text-sm ${
                          addedProductId === product.id
                            ? 'bg-green-600 text-white'
                            : 'bg-blue-600 hover:bg-blue-700 text-white'
                        }`}
                      >
                        {addedProductId === product.id ? 'Added!' : 'Add to Cart'}
                      </button>
                      <p className="text-xs text-green-600 mt-1 sm:mt-2 font-semibold">✓ Free delivery</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Product Detail Page
  if (currentPage === 'product' && selectedProduct) {
    return (
      <div className="min-h-screen bg-gray-50">
        {renderHeader()}
        
        <div className="bg-white shadow-md border-b">
          <div className="container mx-auto px-2 sm:px-4 py-4">
            <div className="flex items-center space-x-2 text-sm text-gray-600">
              <button onClick={handleBackToHome} className="hover:text-blue-600 font-medium">
                Home
              </button>
              <span>/</span>
              <button onClick={handleBackToCategory} className="hover:text-blue-600 font-medium">
                {selectedCategory}
              </button>
              <span>/</span>
              <span className="text-gray-900 font-bold truncate">{selectedProduct?.name}</span>
            </div>
          </div>
        </div>

        <div className="container mx-auto px-2 sm:px-4 py-4 sm:py-8">
          <div className="bg-white rounded-xl shadow-lg border overflow-hidden">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-8 p-4 sm:p-8">
              <div className="space-y-4 sm:space-y-6">
                <div className="aspect-square bg-gradient-to-br from-gray-100 to-gray-200 rounded-xl overflow-hidden shadow-inner">
                  <img
                    src={selectedProduct.image}
                    alt={selectedProduct.name}
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                  />
                </div>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                  <button 
                    className="bg-gradient-to-r from-yellow-400 to-yellow-500 hover:from-yellow-500 hover:to-yellow-600 text-gray-900 py-3 sm:py-4 px-4 sm:px-6 rounded-xl font-bold transition-all duration-300 transform hover:-translate-y-1 shadow-lg hover:shadow-xl flex items-center justify-center text-sm sm:text-base"
                    onClick={() => handleAddToCart(selectedProduct, quantity)}
                  >
                    <ShoppingCart className="w-4 h-4 sm:w-5 sm:h-5 mr-2" />
                    Add to Cart
                  </button>
                  <button 
                    className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white py-3 sm:py-4 px-4 sm:px-6 rounded-xl font-bold transition-all duration-300 transform hover:-translate-y-1 shadow-lg hover:shadow-xl text-sm sm:text-base"
                    onClick={() => {
                      handleAddToCart(selectedProduct, quantity);
                      navigate('/checkout');
                    }}
                  >
                    Buy Now
                  </button>
                </div>
              </div>

              <div className="space-y-4 sm:space-y-6">
                <div>
                  <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-2 sm:mb-3">{selectedProduct.name}</h1>
                  <p className="text-gray-600 mb-3 sm:mb-4 text-base sm:text-lg">by <span className="font-semibold text-blue-600">{selectedProduct.brand}</span></p>
                  
                  <div className="flex items-center space-x-3 sm:space-x-4 mb-4 sm:mb-6">
                    <div className="flex items-center bg-green-600 text-white px-2 sm:px-3 py-1 sm:py-2 rounded-lg shadow-md">
                      <span className="font-bold text-base sm:text-lg">{selectedProduct.rating}</span>
                      <Star className="w-3 h-3 sm:w-4 sm:h-4 ml-1 fill-current" />
                    </div>
                    <span className="text-gray-600 font-medium text-sm sm:text-base">{selectedProduct.reviews.toLocaleString()} reviews</span>
                    <span className="text-green-600 font-semibold text-sm sm:text-base">✓ Verified</span>
                  </div>

                  <div className="flex items-center space-x-3 sm:space-x-4 mb-6 sm:mb-8">
                    <span className="text-3xl sm:text-4xl font-bold text-gray-900">₹{selectedProduct.price.toLocaleString()}</span>
                    {selectedProduct.originalPrice && (
                      <>
                        <span className="text-xl sm:text-2xl text-gray-500 line-through">₹{selectedProduct.originalPrice.toLocaleString()}</span>
                        <span className="bg-green-100 text-green-800 px-2 sm:px-3 py-1 rounded-full font-bold text-sm sm:text-lg">
                          {selectedProduct.discount}% OFF
                        </span>
                      </>
                    )}
                  </div>
                </div>

                <div className="space-y-3">
                  <h3 className="font-bold text-gray-800">Size</h3>
                  <div className="flex space-x-2 sm:space-x-3">
                    {['S', 'M', 'L', 'XL', 'XXL'].map((size) => (
                      <button
                        key={size}
                        onClick={() => setSelectedSize(size)}
                        className={`w-10 h-10 sm:w-12 sm:h-12 rounded-lg border-2 font-bold transition-all text-sm sm:text-base ${
                          selectedSize === size
                            ? 'border-blue-500 bg-blue-50 text-blue-600'
                            : 'border-gray-300 hover:border-gray-400'
                        }`}
                      >
                        {size}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-3">
                  <h3 className="font-bold text-gray-800">Quantity</h3>
                  <div className="flex items-center space-x-3">
                    <button
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      className="w-8 h-8 sm:w-10 sm:h-10 rounded-lg border-2 border-gray-300 hover:border-gray-400 flex items-center justify-center"
                    >
                      <Minus className="w-3 h-3 sm:w-4 sm:h-4" />
                    </button>
                    <span className="w-10 sm:w-12 text-center font-bold text-base sm:text-lg">{quantity}</span>
                    <button
                      onClick={() => setQuantity(quantity + 1)}
                      className="w-8 h-8 sm:w-10 sm:h-10 rounded-lg border-2 border-gray-300 hover:border-gray-400 flex items-center justify-center"
                    >
                      <Plus className="w-3 h-3 sm:w-4 sm:h-4" />
                    </button>
                  </div>
                </div>

                <div className="space-y-3 sm:space-y-4 bg-gradient-to-r from-blue-50 to-purple-50 p-4 sm:p-6 rounded-xl">
                  <div className="flex items-center space-x-3 text-green-600">
                    <Truck className="w-5 h-5 sm:w-6 sm:h-6" />
                    <div>
                      <span className="font-bold text-sm sm:text-base">Free Delivery</span>
                      <p className="text-xs sm:text-sm text-gray-600">Get it delivered by tomorrow</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3 text-blue-600">
                    <RefreshCw className="w-5 h-5 sm:w-6 sm:h-6" />
                    <div>
                      <span className="font-bold text-sm sm:text-base">7 Days Replacement</span>
                      <p className="text-xs sm:text-sm text-gray-600">Easy returns within 7 days</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3 text-purple-600">
                    <Shield className="w-5 h-5 sm:w-6 sm:h-6" />
                    <div>
                      <span className="font-bold text-sm sm:text-base">1 Year Warranty</span>
                      <p className="text-xs sm:text-sm text-gray-600">Brand warranty included</p>
                    </div>
                  </div>
                </div>

                <div className="flex space-x-4 sm:space-x-6 pt-4">
                  <button className="flex items-center space-x-2 text-gray-600 hover:text-red-500 transition-colors font-medium text-sm sm:text-base">
                    <Heart className="w-4 h-4 sm:w-5 sm:h-5" />
                    <span>Add to Wishlist</span>
                  </button>
                  <button className="flex items-center space-x-2 text-gray-600 hover:text-blue-500 transition-colors font-medium text-sm sm:text-base">
                    <Share2 className="w-4 h-4 sm:w-5 sm:h-5" />
                    <span>Share Product</span>
                  </button>
                </div>
              </div>
            </div>

            <div className="mt-8 sm:mt-12">
              {renderCategoryCarousel(`🔥 More from ${selectedCategory}`, productData[selectedCategory]?.filter(p => p.id !== selectedProduct.id) || [])}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return null;
};

export default Products;
