import React from 'react';

const ProductCard = ({
  product,
  onProductClick,
  onAddToCart,
  isAdded,
  isInCart,
}) => (
  <div
    className="cursor-pointer group bg-white border-2 border-gray-100 rounded-xl hover:border-blue-300 hover:shadow-xl transition-all duration-300 overflow-hidden transform hover:-translate-y-2 relative"
    onClick={() => onProductClick(product)}
  >
    <div className="relative group">
      <img
        src={product.image}
        alt={product.name}
        className="w-full h-52 object-cover group-hover:scale-110 transition-transform duration-500"
      />
      {/* Discount Badge */}
      {product.discount && (
        <div className="absolute top-3 left-3 bg-gradient-to-r from-green-500 to-emerald-500 text-white px-3 py-1 rounded-full text-xs font-bold shadow-md">
          {product.discount}% OFF
        </div>
      )}
    </div>
    <div className="p-4 pb-14">
      <h3 className="font-semibold text-gray-800 mb-2 text-sm line-clamp-2 group-hover:text-blue-600 transition-colors">
        {product.name}
      </h3>
      <p className="text-gray-500 text-xs mb-3 font-medium">{product.brand}</p>
      <div className="flex items-center mb-3">
        <div className="flex items-center bg-green-600 text-white px-2 py-1 rounded-md text-xs font-bold mr-2 shadow-sm">
          <span>{product.rating}</span>
          <svg className="w-3 h-3 ml-1 fill-current" fill="yellow" viewBox="0 0 24 24"><polygon points="12,17.6 5.5,21 7.2,13.9 1.6,8.6 8.9,7.8 12,1 15.1,7.8 22.4,8.6 16.8,13.9 18.5,21 " /></svg>
        </div>
        <span className="text-xs text-gray-500 font-medium">
          ({product.reviews.toLocaleString()})
        </span>
      </div>
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <span className="text-lg font-bold text-gray-900">₹{product.price.toLocaleString()}</span>
          {product.originalPrice && (
            <span className="text-sm text-gray-500 line-through font-medium">₹{product.originalPrice.toLocaleString()}</span>
          )}
        </div>
      </div>
      <p className="text-xs text-green-600 mt-2 font-semibold">✓ Free delivery</p>
    </div>
    {/* Add to Cart Button */}
    <button
      onClick={e => {
        e.stopPropagation();
        onAddToCart(product);
      }}
      className={`absolute bottom-2 left-2 right-2 bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg transition-all ${isAdded ? 'opacity-80' : ''}`}
    >
      {isAdded ? "Added!" : isInCart ? "Add More" : "Add to Cart"}
    </button>
  </div>
);

export default ProductCard;
