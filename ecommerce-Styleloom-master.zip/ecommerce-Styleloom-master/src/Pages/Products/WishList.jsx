// src/Pages/Wishlist.jsx
import React from "react";
import { Heart, ShoppingCart, ArrowLeft, Trash2, Package } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const Wishlist = ({ wishlistItems = [], removeFromWishlist, addToCart, isInWishlist }) => {
  const navigate = useNavigate();

  const handleAddToCart = (product) => {
    addToCart(product);
  };

  const handleRemoveFromWishlist = (productId) => {
    removeFromWishlist(productId);
  };

  return (
    <>
      <style>
        {`
          .wishlist-item-hover {
            transition: all 0.3s ease;
          }
          .wishlist-item-hover:hover {
            transform: translateY(-4px);
            box-shadow: 0 12px 32px rgba(0, 0, 0, 0.15);
          }
          .heart-beat {
            animation: heartBeat 1.5s ease-in-out infinite;
          }
          @keyframes heartBeat {
            0% { transform: scale(1); }
            14% { transform: scale(1.1); }
            28% { transform: scale(1); }
            42% { transform: scale(1.1); }
            70% { transform: scale(1); }
          }
        `}
      </style>
      
      <div className="min-h-screen bg-gradient-to-br from-pink-50 to-red-50">
        {/* Header */}
        <header className="bg-white shadow-md border-b sticky top-0 z-50">
          <div className="container mx-auto px-4 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <button
                  onClick={() => navigate(-1)}
                  className="flex items-center space-x-2 bg-gray-100 hover:bg-gray-200 text-gray-700 px-4 py-2 rounded-xl transition-all duration-300"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span className="text-sm font-medium">Back</span>
                </button>
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gradient-to-r from-pink-500 to-red-500 rounded-xl flex items-center justify-center shadow-lg">
                    <Heart className="w-5 h-5 text-white fill-current heart-beat" />
                  </div>
                  <div>
                    <h1 className="text-2xl font-bold text-gray-800">My Wishlist</h1>
                    <p className="text-gray-600 text-sm">{wishlistItems.length} items saved</p>
                  </div>
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <button
                  onClick={() => navigate('/products')}
                  className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white px-6 py-2 rounded-xl font-medium transition-all duration-300 transform hover:-translate-y-1 shadow-lg"
                >
                  Continue Shopping
                </button>
              </div>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="container mx-auto px-4 py-8">
          {wishlistItems.length === 0 ? (
            /* Empty State */
            <div className="text-center py-20">
              <div className="w-32 h-32 bg-gradient-to-r from-pink-100 to-red-100 rounded-full flex items-center justify-center mx-auto mb-8 shadow-lg">
                <Heart className="w-16 h-16 text-gray-400" />
              </div>
              <h2 className="text-3xl font-bold text-gray-800 mb-4">Your wishlist is empty</h2>
              <p className="text-gray-600 mb-8 max-w-md mx-auto">
                Save your favorite items to your wishlist and never lose track of what you love!
              </p>
              <button
                onClick={() => navigate('/products')}
                className="bg-gradient-to-r from-pink-500 to-red-500 hover:from-pink-600 hover:to-red-600 text-white px-8 py-3 rounded-xl font-medium transition-all duration-300 transform hover:-translate-y-1 shadow-lg"
              >
                Start Shopping
              </button>
            </div>
          ) : (
            /* Wishlist Items */
            <>
              {/* Stats */}
              <div className="bg-white rounded-2xl p-6 mb-8 shadow-lg border">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-gradient-to-r from-pink-500 to-red-500 rounded-xl flex items-center justify-center shadow-lg">
                      <Heart className="w-6 h-6 text-white fill-current" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-gray-800">Your Saved Items</h3>
                      <p className="text-gray-600">{wishlistItems.length} products in your wishlist</p>
                    </div>
                  </div>
                  <div className="hidden md:flex items-center space-x-6">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-gray-800">{wishlistItems.length}</div>
                      <div className="text-xs text-gray-500">Items</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-green-600">
                        ₹{wishlistItems.reduce((sum, item) => sum + item.price, 0).toLocaleString()}
                      </div>
                      <div className="text-xs text-gray-500">Total Value</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Wishlist Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {wishlistItems.map((item) => (
                  <div
                    key={item.id}
                    className="bg-white rounded-2xl p-4 shadow-lg border wishlist-item-hover group"
                  >
                    {/* Product Image */}
                    <div className="relative mb-4">
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-full h-56 object-cover rounded-xl group-hover:scale-105 transition-transform duration-500"
                      />
                      {/* Remove from Wishlist Button */}
                      <button
                        onClick={() => handleRemoveFromWishlist(item.id)}
                        className="absolute top-3 right-3 w-9 h-9 bg-red-500 hover:bg-red-600 text-white rounded-full flex items-center justify-center shadow-lg transition-all duration-300 transform hover:scale-110"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                      {/* Discount Badge */}
                      {item.discount && (
                        <div className="absolute top-3 left-3 bg-gradient-to-r from-green-500 to-emerald-500 text-white px-3 py-1 rounded-full text-xs font-bold shadow-md">
                          {item.discount}% OFF
                        </div>
                      )}
                    </div>

                    {/* Product Details */}
                    <div className="space-y-3">
                      <div>
                        <h3 className="font-semibold text-gray-800 text-base line-clamp-2 group-hover:text-blue-600 transition-colors">
                          {item.name}
                        </h3>
                        <p className="text-gray-500 text-sm font-medium mt-1">{item.brand}</p>
                      </div>

                      {/* Rating */}
                      {item.rating && (
                        <div className="flex items-center space-x-2">
                          <div className="flex items-center bg-green-600 text-white px-2 py-1 rounded-md text-xs font-bold shadow-sm">
                            <span>{item.rating}</span>
                            <Heart className="w-3 h-3 ml-1 fill-current" />
                          </div>
                          {item.reviews && (
                            <span className="text-xs text-gray-500 font-medium">
                              ({item.reviews.toLocaleString()} reviews)
                            </span>
                          )}
                        </div>
                      )}

                      {/* Price */}
                      <div className="flex items-center space-x-2">
                        <span className="text-xl font-bold text-gray-900">₹{item.price.toLocaleString()}</span>
                        {item.originalPrice && (
                          <span className="text-sm text-gray-500 line-through font-medium">
                            ₹{item.originalPrice.toLocaleString()}
                          </span>
                        )}
                      </div>

                      {/* Action Buttons */}
                      <div className="space-y-2">
                        <button
                          onClick={() => handleAddToCart(item)}
                          className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white py-3 px-4 rounded-xl font-medium transition-all duration-300 transform hover:-translate-y-1 shadow-lg flex items-center justify-center space-x-2"
                        >
                          <ShoppingCart className="w-4 h-4" />
                          <span>Add to Cart</span>
                        </button>
                        
                        <div className="flex space-x-2">
                          <button
                            onClick={() => navigate(`/product/${item.id}`)}
                            className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-700 py-2 px-4 rounded-xl font-medium transition-all duration-300"
                          >
                            View Details
                          </button>
                          <button
                            onClick={() => handleRemoveFromWishlist(item.id)}
                            className="bg-red-100 hover:bg-red-200 text-red-600 py-2 px-4 rounded-xl font-medium transition-all duration-300"
                          >
                            Remove
                          </button>
                        </div>
                      </div>

                      <p className="text-xs text-green-600 font-semibold">✓ Free delivery</p>
                    </div>
                  </div>
                ))}
              </div>

              {/* Quick Actions */}
              <div className="mt-12 bg-white rounded-2xl p-6 shadow-lg border">
                <div className="flex flex-col md:flex-row items-center justify-between space-y-4 md:space-y-0">
                  <div>
                    <h3 className="text-lg font-bold text-gray-800 mb-1">Quick Actions</h3>
                    <p className="text-gray-600 text-sm">Manage your wishlist items efficiently</p>
                  </div>
                  <div className="flex space-x-4">
                    <button
                      onClick={() => {
                        wishlistItems.forEach(item => addToCart(item));
                      }}
                      className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white px-6 py-3 rounded-xl font-medium transition-all duration-300 transform hover:-translate-y-1 shadow-lg flex items-center space-x-2"
                    >
                      <Package className="w-4 h-4" />
                      <span>Add All to Cart</span>
                    </button>
                    <button
                      onClick={() => navigate('/products')}
                      className="bg-gray-100 hover:bg-gray-200 text-gray-700 px-6 py-3 rounded-xl font-medium transition-all duration-300"
                    >
                      Continue Shopping
                    </button>
                  </div>
                </div>
              </div>
            </>
          )}
        </main>
      </div>
    </>
  );
};

export default Wishlist;
