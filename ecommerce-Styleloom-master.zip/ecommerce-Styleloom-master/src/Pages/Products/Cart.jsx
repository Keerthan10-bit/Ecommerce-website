// src/Pages/Cart/Cart.jsx
import React from "react";
import { Trash2, Plus, Minus, ShoppingCart, ArrowLeft, CreditCard, Facebook, Twitter, Instagram, Youtube, Mail, Phone, MapPin, Heart } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const Cart = ({ cartItems = [], updateQuantity, removeFromCart }) => {
  const navigate = useNavigate();
  
  const subtotal = cartItems.reduce(
    (sum, item) => sum + item.price * item.quantity, 0
  );

  return (
    <>
      <style>
        {`
          .cart-item-hover {
            transition: all 0.3s ease;
          }
          .cart-item-hover:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.3);
          }
          .quantity-btn {
            transition: all 0.2s ease;
          }
          .quantity-btn:hover {
            transform: scale(1.1);
          }
          .glass-effect {
            backdrop-filter: blur(10px);
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
          }
          .footer-link {
            transition: all 0.3s ease;
          }
          .footer-link:hover {
            transform: translateY(-2px);
          }
          .social-icon {
            transition: all 0.3s ease;
          }
          .social-icon:hover {
            transform: scale(1.2) rotate(5deg);
          }
          .checkout-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 30px rgba(59, 130, 246, 0.4);
          }
        `}
      </style>
      
      <div className="min-h-screen bg-gradient-to-br from-[#1e293b] via-[#334155] to-[#475569] text-white font-['Inter']">
        {/* Enhanced Header */}
        <header className="relative border-b border-slate-600/30 py-8 bg-gradient-to-r from-[#0f172a] via-[#1e293b] to-[#334155] shadow-2xl">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center shadow-xl">
                  <ShoppingCart className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className="text-2xl lg:text-3xl font-bold text-white">StyleLoom</h1>
                  <p className="text-slate-300 text-sm">Your Shopping Cart</p>
                </div>
              </div>
              <div className="hidden md:flex items-center space-x-8">
                <div className="text-center">
                  <div className="text-3xl font-bold text-white">{cartItems.length}</div>
                  <div className="text-xs text-slate-300 uppercase tracking-wider">Items</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold bg-gradient-to-r from-green-400 to-emerald-500 bg-clip-text text-transparent">₹{subtotal.toLocaleString()}</div>
                  <div className="text-xs text-slate-300 uppercase tracking-wider">Total</div>
                </div>
              </div>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="py-8 sm:py-12 min-h-[calc(100vh-200px)]">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col lg:flex-row gap-8 lg:gap-12">
              {/* Cart Main */}
              <div className="flex-1">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-8">
                  <h1 className="font-bold text-3xl sm:text-4xl text-white flex items-center mb-4 sm:mb-0">
                    <ShoppingCart className="w-8 h-8 sm:w-10 sm:h-10 mr-3 sm:mr-4 text-blue-400" />
                    Shopping Cart
                  </h1>
                  <button
                    onClick={() => navigate('/products')}
                    className="flex items-center space-x-3 bg-gradient-to-r from-slate-600 to-slate-700 hover:from-slate-500 hover:to-slate-600 text-white px-6 py-3 rounded-2xl transition-all duration-300 transform hover:-translate-y-1 shadow-xl w-fit"
                    type="button"
                  >
                    <ArrowLeft className="w-5 h-5" />
                    <span className="font-medium">Continue Shopping</span>
                  </button>
                </div>

                {cartItems.length === 0 ? (
                  <div className="bg-gradient-to-r from-[#0f172a] to-[#1e293b] rounded-3xl p-12 sm:p-16 text-center border border-slate-600/30 shadow-2xl">
                    <div className="w-24 h-24 sm:w-32 sm:h-32 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-6 sm:mb-8 shadow-2xl">
                      <ShoppingCart className="w-12 h-12 sm:w-16 sm:h-16 text-white" />
                    </div>
                    <h3 className="text-2xl sm:text-3xl font-bold text-white mb-4">Your cart is empty</h3>
                    <p className="text-slate-400 mb-8 text-lg">Add some amazing products to get started!</p>
                    <button
                      onClick={() => navigate('/products')}
                      className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white px-10 py-4 rounded-2xl font-bold text-lg transition-all duration-300 transform hover:-translate-y-1 shadow-xl"
                    >
                      Start Shopping
                    </button>
                  </div>
                ) : (
                  <>
                    {/* Desktop Table */}
                    <div className="hidden lg:block bg-gradient-to-r from-[#0f172a] to-[#1e293b] border border-slate-600/30 rounded-3xl overflow-hidden mb-8 shadow-2xl">
                      <div className="bg-gradient-to-r from-[#1e293b] to-[#334155] grid grid-cols-[120px_1fr_200px_150px_120px] h-20 items-center px-8 text-white text-base font-bold border-b border-slate-600/30">
                        <div>Product</div>
                        <div>Details</div>
                        <div className="text-center">Quantity</div>
                        <div className="text-center">Price</div>
                        <div className="text-center">Total</div>
                      </div>
                      {cartItems.map((item) => (
                        <div
                          key={item.id}
                          className="grid grid-cols-[120px_1fr_200px_150px_120px] min-h-[120px] items-center border-b border-slate-700/30 last:border-b-0 px-8 py-6 cart-item-hover hover:bg-gradient-to-r hover:from-[#1e293b] hover:to-[#334155]"
                        >
                          <div className="flex items-center justify-center">
                            <div className="relative group">
                              <img
                                src={item.image}
                                alt={item.name}
                                className="w-20 h-20 rounded-2xl object-cover shadow-xl border-2 border-slate-600 group-hover:border-blue-400 transition-all duration-300"
                              />
                              <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-20 rounded-2xl transition-all duration-300"></div>
                            </div>
                          </div>
                          <div className="px-6">
                            <h3 className="font-bold text-white text-lg mb-2 line-clamp-2">{item.name}</h3>
                            <p className="text-slate-400 text-base">{item.brand}</p>
                          </div>
                          <div className="flex justify-center items-center gap-4">
                            <button
                              onClick={() => updateQuantity(item.id, item.quantity - 1)}
                              disabled={item.quantity <= 1}
                              className="quantity-btn w-10 h-10 bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 disabled:from-slate-500 disabled:to-slate-600 text-white rounded-xl flex items-center justify-center shadow-xl disabled:opacity-50 transition-all duration-200"
                            >
                              <Minus className="w-5 h-5" />
                            </button>
                            <span className="w-16 text-center font-bold text-white text-xl bg-[#1e293b] py-3 rounded-xl border border-slate-600">{item.quantity}</span>
                            <button
                              onClick={() => updateQuantity(item.id, item.quantity + 1)}
                              className="quantity-btn w-10 h-10 bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white rounded-xl flex items-center justify-center shadow-xl transition-all duration-200"
                            >
                              <Plus className="w-5 h-5" />
                            </button>
                            <button
                              onClick={() => removeFromCart(item.id)}
                              className="quantity-btn w-10 h-10 bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white rounded-xl flex items-center justify-center shadow-xl transition-all duration-200 ml-2"
                            >
                              <Trash2 className="w-5 h-5" />
                            </button>
                          </div>
                          <div className="text-center">
                            <div className="font-bold text-white text-lg">₹{item.price.toLocaleString()}</div>
                          </div>
                          <div className="text-center">
                            <div className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-4 py-3 rounded-2xl font-bold text-base shadow-xl">
                              ₹{(item.price * item.quantity).toLocaleString()}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Tablet Table */}
                    <div className="hidden md:block lg:hidden bg-gradient-to-r from-[#0f172a] to-[#1e293b] border border-slate-600/30 rounded-3xl overflow-hidden mb-8 shadow-2xl">
                      <div className="bg-gradient-to-r from-[#1e293b] to-[#334155] grid grid-cols-[100px_1fr_150px_100px] h-16 items-center px-6 text-white text-sm font-bold border-b border-slate-600/30">
                        <div>Product</div>
                        <div>Details</div>
                        <div className="text-center">Quantity</div>
                        <div className="text-center">Total</div>
                      </div>
                      {cartItems.map((item) => (
                        <div
                          key={item.id}
                          className="grid grid-cols-[100px_1fr_150px_100px] min-h-[100px] items-center border-b border-slate-700/30 last:border-b-0 px-6 py-4 cart-item-hover hover:bg-gradient-to-r hover:from-[#1e293b] hover:to-[#334155]"
                        >
                          <div className="flex items-center justify-center">
                            <img
                              src={item.image}
                              alt={item.name}
                              className="w-16 h-16 rounded-xl object-cover shadow-lg border-2 border-slate-600"
                            />
                          </div>
                          <div className="px-4">
                            <h3 className="font-bold text-white text-base mb-1 line-clamp-2">{item.name}</h3>
                            <p className="text-slate-400 text-sm mb-1">{item.brand}</p>
                            <p className="text-slate-300 text-sm font-medium">₹{item.price.toLocaleString()}</p>
                          </div>
                          <div className="flex justify-center items-center gap-2">
                            <button
                              onClick={() => updateQuantity(item.id, item.quantity - 1)}
                              disabled={item.quantity <= 1}
                              className="quantity-btn w-8 h-8 bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 disabled:from-slate-500 disabled:to-slate-600 text-white rounded-lg flex items-center justify-center shadow-lg disabled:opacity-50 transition-all duration-200"
                            >
                              <Minus className="w-4 h-4" />
                            </button>
                            <span className="w-12 text-center font-bold text-white text-lg bg-[#1e293b] py-2 rounded-lg border border-slate-600">{item.quantity}</span>
                            <button
                              onClick={() => updateQuantity(item.id, item.quantity + 1)}
                              className="quantity-btn w-8 h-8 bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white rounded-lg flex items-center justify-center shadow-lg transition-all duration-200"
                            >
                              <Plus className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => removeFromCart(item.id)}
                              className="quantity-btn w-8 h-8 bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white rounded-lg flex items-center justify-center shadow-lg transition-all duration-200 ml-1"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                          <div className="text-center">
                            <div className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-3 py-2 rounded-xl font-bold text-sm shadow-lg">
                              ₹{(item.price * item.quantity).toLocaleString()}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Mobile Cards */}
                    <div className="md:hidden space-y-6">
                      {cartItems.map((item) => (
                        <div key={item.id} className="bg-gradient-to-r from-[#0f172a] to-[#1e293b] border border-slate-600/30 rounded-3xl p-6 cart-item-hover shadow-2xl">
                          <div className="flex items-start space-x-4 mb-4">
                            <img
                              src={item.image}
                              alt={item.name}
                              className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl object-cover shadow-xl border-2 border-slate-600"
                            />
                            <div className="flex-1 min-w-0">
                              <h3 className="font-bold text-white text-base sm:text-lg mb-2 line-clamp-2">{item.name}</h3>
                              <p className="text-slate-400 text-sm sm:text-base mb-2">{item.brand}</p>
                              <div className="text-white font-bold text-lg sm:text-xl">₹{item.price.toLocaleString()}</div>
                            </div>
                          </div>
                          
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-3">
                              <button
                                onClick={() => updateQuantity(item.id, item.quantity - 1)}
                                disabled={item.quantity <= 1}
                                className="w-10 h-10 bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 disabled:from-slate-500 disabled:to-slate-600 text-white rounded-xl flex items-center justify-center transition-all disabled:opacity-50"
                              >
                                <Minus className="w-5 h-5" />
                              </button>
                              <span className="w-16 text-center font-bold text-white text-xl bg-[#1e293b] py-3 rounded-xl border border-slate-600">{item.quantity}</span>
                              <button
                                onClick={() => updateQuantity(item.id, item.quantity + 1)}
                                className="w-10 h-10 bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white rounded-xl flex items-center justify-center transition-all"
                              >
                                <Plus className="w-5 h-5" />
                              </button>
                            </div>
                            <button
                              onClick={() => removeFromCart(item.id)}
                              className="w-10 h-10 bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white rounded-xl flex items-center justify-center transition-all"
                            >
                              <Trash2 className="w-5 h-5" />
                            </button>
                          </div>
                          
                          <div className="mt-6 pt-6 border-t border-slate-600/30 flex justify-between items-center">
                            <span className="text-slate-400 text-lg">Item Total:</span>
                            <span className="text-white font-bold text-2xl">₹{(item.price * item.quantity).toLocaleString()}</span>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Subtotal */}
                    <div className="bg-gradient-to-r from-[#0f172a] to-[#1e293b] rounded-3xl p-6 sm:p-8 mt-8 border border-slate-600/30 shadow-2xl">
                      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center">
                        <span className="text-xl sm:text-2xl text-slate-300 font-bold mb-2 sm:mb-0">Subtotal:</span>
                        <span className="text-3xl sm:text-4xl font-bold bg-gradient-to-r from-green-400 to-emerald-500 bg-clip-text text-transparent">₹{subtotal.toLocaleString()}</span>
                      </div>
                      <div className="mt-6 text-sm sm:text-base text-slate-400 space-y-2">
                        <p>• Free shipping on orders over ₹500</p>
                        <p>• Tax will be calculated at checkout</p>
                        <p>• 7-day return policy</p>
                      </div>
                    </div>
                  </>
                )}
              </div>

              {/* Enhanced Sidebar */}
              <aside className="w-full lg:w-[450px] xl:w-[500px]">
                <div className="bg-gradient-to-br from-[#0f172a] to-[#1e293b] rounded-3xl p-6 sm:p-8 border border-slate-600/30 shadow-2xl sticky top-8">
                  <h2 className="font-bold text-2xl sm:text-3xl text-white mb-6 sm:mb-8 flex items-center">
                    <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl flex items-center justify-center mr-4">
                      <ShoppingCart className="w-5 h-5 text-white" />
                    </div>
                    Order Summary
                  </h2>
                  
                  {cartItems.length === 0 ? (
                    <div className="text-center py-12">
                      <div className="w-20 h-20 bg-slate-600 rounded-full flex items-center justify-center mx-auto mb-6">
                        <ShoppingCart className="w-10 h-10 text-slate-400" />
                      </div>
                      <p className="text-slate-400 text-lg">No items in cart</p>
                    </div>
                  ) : (
                    <>
                      <div className="space-y-4 mb-8 max-h-80 overflow-y-auto">
                        {cartItems.map((item) => (
                          <div key={item.id} className="flex items-center space-x-4 p-4 bg-[#1e293b] rounded-2xl border border-slate-600/30 hover:border-slate-500/50 transition-all">
                            <img
                              src={item.image}
                              alt={item.name}
                              className="w-16 h-16 rounded-xl object-cover border border-slate-600"
                            />
                            <div className="flex-1 min-w-0">
                              <div className="font-bold text-white text-base truncate">{item.name}</div>
                              <div className="text-slate-400 text-sm">₹{item.price} × {item.quantity}</div>
                            </div>
                            <div className="text-white font-bold text-base">₹{(item.price * item.quantity).toLocaleString()}</div>
                          </div>
                        ))}
                      </div>

                      <div className="border-t border-slate-600/30 pt-6 space-y-4">
                        <div className="flex justify-between text-slate-300 text-lg">
                          <span>Items ({cartItems.length}):</span>
                          <span>₹{subtotal.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between text-slate-300 text-lg">
                          <span>Shipping:</span>
                          <span className="text-green-400 font-bold">Free</span>
                        </div>
                        <div className="flex justify-between text-slate-300 text-lg">
                          <span>Tax:</span>
                          <span>Calculated at checkout</span>
                        </div>
                        <div className="border-t border-slate-600/30 pt-4">
                          <div className="flex justify-between items-center">
                            <span className="font-bold text-white text-xl sm:text-2xl">Total:</span>
                            <span className="font-bold text-2xl sm:text-3xl bg-gradient-to-r from-green-400 to-emerald-500 bg-clip-text text-transparent">₹{subtotal.toLocaleString()}</span>
                          </div>
                        </div>
                      </div>

                      <button
                        className="checkout-btn w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white py-4 sm:py-5 px-8 rounded-2xl font-bold text-lg sm:text-xl transition-all duration-300 transform shadow-2xl mt-8 flex items-center justify-center space-x-3"
                        type="button"
                        onClick={() => navigate("/checkout")}
                        disabled={cartItems.length === 0}
                      >
                        <CreditCard className="w-5 h-5 sm:w-6 sm:h-6" />
                        <span>Proceed to Checkout</span>
                      </button>

                      <div className="mt-6 text-center">
                        <button
                          onClick={() => navigate('/products')}
                          className="text-blue-400 hover:text-blue-300 text-base font-medium transition-colors"
                        >
                          Continue Shopping
                        </button>
                      </div>
                    </>
                  )}

                  {/* Trust Badges */}
                  <div className="mt-8 pt-8 border-t border-slate-600/30">
                    <div className="grid grid-cols-2 gap-4 text-center">
                      <div className="glass-effect rounded-2xl p-4">
                        <div className="text-green-400 text-sm font-bold mb-2">✓ SECURE</div>
                        <div className="text-slate-300 text-xs">SSL Protected</div>
                      </div>
                      <div className="glass-effect rounded-2xl p-4">
                        <div className="text-blue-400 text-sm font-bold mb-2">✓ FAST</div>
                        <div className="text-slate-300 text-xs">Quick Delivery</div>
                      </div>
                    </div>
                  </div>
                </div>
              </aside>
            </div>
          </div>
        </main>

        {/* Enhanced Footer */}
        <footer className="w-full bg-gradient-to-b from-[#0f172a] to-[#020617] border-t border-slate-600/30 mt-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
            {/* Main Footer Content */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
              {/* Brand Section */}
              <div className="space-y-6">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center shadow-xl">
                    <ShoppingCart className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="text-3xl font-bold text-white">StyleLoom</h3>
                </div>
                <p className="text-slate-400 text-base leading-relaxed">
                  Your ultimate destination for fashion, electronics, and lifestyle products. 
                  Quality guaranteed, delivered fast.
                </p>
                <div className="flex space-x-4">
                  <button className="social-icon w-12 h-12 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 rounded-2xl flex items-center justify-center transition-all">
                    <Facebook className="w-6 h-6 text-white" />
                  </button>
                  <button className="social-icon w-12 h-12 bg-gradient-to-r from-blue-400 to-blue-500 hover:from-blue-500 hover:to-blue-600 rounded-2xl flex items-center justify-center transition-all">
                    <Twitter className="w-6 h-6 text-white" />
                  </button>
                  <button className="social-icon w-12 h-12 bg-gradient-to-r from-pink-500 to-red-500 hover:from-pink-600 hover:to-red-600 rounded-2xl flex items-center justify-center transition-all">
                    <Instagram className="w-6 h-6 text-white" />
                  </button>
                  <button className="social-icon w-12 h-12 bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 rounded-2xl flex items-center justify-center transition-all">
                    <Youtube className="w-6 h-6 text-white" />
                  </button>
                </div>
              </div>

              {/* Quick Links */}
              <div className="space-y-6">
                <h4 className="text-xl font-bold text-white">Quick Links</h4>
                <div className="space-y-3">
                  <a href="/products" className="footer-link block text-slate-400 hover:text-white text-base transition-all">All Products</a>
                  <a href="/categories" className="footer-link block text-slate-400 hover:text-white text-base transition-all">Categories</a>
                  <a href="/deals" className="footer-link block text-slate-400 hover:text-white text-base transition-all">Daily Deals</a>
                  <a href="/new-arrivals" className="footer-link block text-slate-400 hover:text-white text-base transition-all">New Arrivals</a>
                  <a href="/wishlist" className="footer-link block text-slate-400 hover:text-white text-base transition-all">
                    <div className="flex items-center space-x-3">
                      <Heart className="w-4 h-4" />
                      <span>Wishlist</span>
                    </div>
                  </a>
                </div>
              </div>

              {/* Customer Service */}
              <div className="space-y-6">
                <h4 className="text-xl font-bold text-white">Customer Service</h4>
                <div className="space-y-3">
                  <a href="/help" className="footer-link block text-slate-400 hover:text-white text-base transition-all">Help Center</a>
                  <a href="/returns" className="footer-link block text-slate-400 hover:text-white text-base transition-all">Returns & Exchanges</a>
                  <a href="/shipping" className="footer-link block text-slate-400 hover:text-white text-base transition-all">Shipping Info</a>
                  <a href="/track" className="footer-link block text-slate-400 hover:text-white text-base transition-all">Track Your Order</a>
                  <a href="/size-guide" className="footer-link block text-slate-400 hover:text-white text-base transition-all">Size Guide</a>
                </div>
              </div>

              {/* Contact Info */}
              <div className="space-y-6">
                <h4 className="text-xl font-bold text-white">Contact Us</h4>
                <div className="space-y-4">
                  <div className="flex items-center space-x-4 text-slate-400 text-base">
                    <Mail className="w-5 h-5 text-blue-400" />
                    <span>support@styleloom.com</span>
                  </div>
                  <div className="flex items-center space-x-4 text-slate-400 text-base">
                    <Phone className="w-5 h-5 text-green-400" />
                    <span>+91 1800-123-4567</span>
                  </div>
                  <div className="flex items-start space-x-4 text-slate-400 text-base">
                    <MapPin className="w-5 h-5 text-red-400 mt-1" />
                    <span>123 Fashion Street,<br />Mumbai, Maharashtra 400001</span>
                  </div>
                </div>
                
                {/* Newsletter */}
                <div className="mt-8">
                  <h5 className="text-base font-bold text-white mb-4">Stay Updated</h5>
                  <div className="flex space-x-3">
                    <input 
                      type="email" 
                      placeholder="Enter email" 
                      className="flex-1 px-4 py-3 bg-[#1e293b] border border-slate-600 rounded-xl text-white text-base focus:outline-none focus:border-blue-400 transition-colors placeholder-slate-400"
                    />
                    <button className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white px-6 py-3 rounded-xl font-bold transition-all">
                      Subscribe
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Payment Methods & Guarantees */}
            <div className="border-t border-slate-600/30 pt-12 mb-12">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                <div>
                  <h5 className="text-lg font-bold text-white mb-6">We Accept</h5>
                  <div className="flex flex-wrap gap-4">
                    <div className="bg-[#1e293b] border border-slate-600 rounded-xl px-4 py-3 text-slate-300 text-base">
                      💳 Visa
                    </div>
                    <div className="bg-[#1e293b] border border-slate-600 rounded-xl px-4 py-3 text-slate-300 text-base">
                      💳 Mastercard
                    </div>
                    <div className="bg-[#1e293b] border border-slate-600 rounded-xl px-4 py-3 text-slate-300 text-base">
                      📱 UPI
                    </div>
                    <div className="bg-[#1e293b] border border-slate-600 rounded-xl px-4 py-3 text-slate-300 text-base">
                      💰 COD
                    </div>
                  </div>
                </div>
                <div>
                  <h5 className="text-lg font-bold text-white mb-6">Our Guarantee</h5>
                  <div className="flex flex-wrap gap-3">
                    <div className="glass-effect rounded-xl px-4 py-3 text-slate-300 text-base">
                      ✓ 30-Day Returns
                    </div>
                    <div className="glass-effect rounded-xl px-4 py-3 text-slate-300 text-base">
                      ✓ Secure Checkout
                    </div>
                    <div className="glass-effect rounded-xl px-4 py-3 text-slate-300 text-base">
                      ✓ Free Shipping
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Bottom Footer */}
            {/* Bootm footer to be added at right with the udpated states  */}
            <div className="border-t border-slate-600/30 pt-8 flex flex-col md:flex-row justify-between items-center">
              <div className="text-slate-400 text-base mb-6 md:mb-0">
                © 2025 StyleLoom. All rights reserved. Made with ❤️ in India
              </div>
              <div className="flex space-x-8 text-base">
                <a href="/privacy" className="footer-link text-slate-400 hover:text-white transition-all">Privacy Policy</a>
                <a href="/terms" className="footer-link text-slate-400 hover:text-white transition-all">Terms of Service</a>
                <a href="/cookies" className="footer-link text-slate-400 hover:text-white transition-all">Cookie Policy</a>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </>
  );
};

export default Cart;
